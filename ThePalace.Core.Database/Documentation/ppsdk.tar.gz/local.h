/*
 * local.h
 *
 * Operating system-specific and compiler-specific types and defines.
 *
 * There is a version of this file for each supported platform. This file is
 * the Unix flavored version.
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __LOCAL__
#define __LOCAL__

#ifndef unix
#define unix    1
#endif

#include <time.h>
#include <stdarg.h>

/* The following define is so the compiler can catch and vestigial remnants of
   LONG.
*/
#ifdef LONG
#undef LONG 
#endif
#define LONG ++++DontUseLONG++++

/* System-independent explicit-precision integer types */
#ifdef __alpha
typedef int            sint32;
typedef unsigned int   uint32;
typedef short          sint16;
typedef unsigned short uint16;
typedef signed char    sint8;
typedef unsigned char  uint8;
#else
#ifdef sparc
typedef long           sint32;
typedef unsigned long  uint32;
typedef short          sint16;
typedef unsigned short uint16;
typedef signed char    sint8;
typedef unsigned char  uint8;
#else
/* Defaults most likely to be right */
typedef long           sint32;
typedef unsigned long  uint32;
typedef short          sint16;
typedef unsigned short uint16;
typedef signed char    sint8;
typedef unsigned char  uint8;
#endif
#endif

/**
 * Scalar type big enough to hold either the largest integer or a pointer.
 */
typedef long AnyType;

#ifdef sun
extern int (*snprintf_fix)(char *buf, int size, char *format, ...);
extern int (*vsnprintf_fix)(char *buf, int size, char *format, va_list args);
#define snprintf snprintf_fix
#define vsnprintf vsnprintf_fix
#endif

#ifdef __osf__
#define SNPRINTF_MISSING
#endif

typedef uint32 IPAddress;

#include <ppsdk/config.h>
#include <ppsdk/maccompat.h>
#include <time.h>

#define HugePtr Ptr
#define huge    

#ifdef CLOCKS_PER_SEC
#define TICK_SECONDS    CLOCKS_PER_SEC
#define GetTicks        clock
#else
#define TICK_SECONDS    1
#define GetTicks        clock
time_t clock(void);
#endif

#ifndef HAVE_BCOPY
#define bcopy(src, dst, count)   memmove(dst, src, count)
#define bzero(dst, count)        memset(dst, 0, count)
#endif

#ifndef HAVE_GETDTABLESIZE
#define getdtablesize()  FD_SETSIZE
#endif

#ifndef min 
#define min(a, b)       ((a) > (b) ? (b) : (a))
#endif

#endif /* __LOCAL__ */
