/*
 * m-assets.h
 *
 * Types, defines and function prototypes for the Palace Asset Manager
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __MASSETS__
#define __MASSETS__        1

#include <time.h>
#include <string.h>
#include <ppsdk/local.h>

#ifdef macintosh
#define ASSET_CREATOR    'mUsr'
#define ASSET_FILETYPE   'mAst'
#define ASSET_FILETYPEPC 'tsAm'

#define ASSET_FAVE       'Fave'
#define RT_PROP          'Prop'
#define RT_USERBASE      'User'
#define RT_IPUSERBASE    'IUsr'
#else
#define ASSET_CREATOR    0x00000000    /* 'mPrp' */
#define ASSET_FILETYPE   0x00000000    /* 'mAst' */

#define ASSET_FAVE       0x46617665    /* 'Fave' */
#define RT_PROP          0x50726f70    /* 'Prop' */
#define RT_USERBASE      0x55736572    /* 'User' */
#define RT_IPUSERBASE    0x49557372    /* 'IUsr' */
#endif

#ifdef unix
typedef sint32  AssetHandle;
typedef sint16  FileHandle;
#else
typedef Handle  AssetHandle;
#endif

typedef sint16  ErrNbr;
typedef sint32  AssetType;
typedef sint32  AssetID;

typedef struct {
    uint32  dataOffset;             /* Swap */
    uint32  dataSize;               /* Swap */
    uint32  assetMapOffset;         /* Swap */
    uint32  assetMapSize;           /* Swap */
} AssetFileHeader;

typedef struct {
    sint32  nbrTypes;
    sint32  nbrAssets;
    sint32  lenNames;
    uint32  typesOffset;            /* Offset into AssetMap */
    uint32  recsOffset;             /* Offset into AssetMap */
    uint32  namesOffset;
} AssetMapHeader;

typedef struct {
    AssetType       assetType;
    sint32          nbrAssets;
    sint32          firstAsset;     /* Index # in Asset Recs List */
} AssetTypeRec;

typedef struct {
    AssetID   idNbr;                /* Unique ID# */
    AssetHandle rHandle;            /* (used for Handle) */
    uint32    dataOffset;
    uint32    dataSize;
    time_t    lastUseTime;          /* seconds since 1/1/1904 */
    sint32    nameOffset;           /* offset into StringList or -1 */
    uint32    flags;
    uint32    crc;
} AssetRec;

typedef struct AssetFileVars {
    struct AssetFileVars *nextAssetFile;
    FileHandle      aRefNum;
    AssetFileHeader afHeader;
    AssetMapHeader  afMap;
    Handle          typeList;
    Handle          assetList;
    Handle          nameList;
#ifdef unix
    Handle          handleList;
    int             nbrLoadedAssets;
    int             nbrAllocHandles;
#endif
    FSSpec          fsSpec;
    Boolean         fileNeedsUpdate;
    AssetType       gLastAssetType;
    sint32          gLastAssetNbr;
    
    FileHandle      tempRefNum;
    FSSpec          tempFSSpec;
    uint32          tempDataSize;
    Boolean         isClosing;
} AssetFileVars;

#define AssetModified   0x01
#define AssetLoaded     0x02
#define AssetPurgeable  0x04
#define AssetProtected  0x08
#define AssetInTempFile 0x10
#define AssetRemove     0x20    /* Marked for removal */

typedef struct {
    AssetID id;
    uint32  crc;
} AssetSpec, *AssetSpecPtr;

typedef struct {
    AssetType       type;
    AssetSpec       spec;
    uint32          blockSize;
    sint32          blockOffset;
    uint16          blockNbr;
    uint16          nbrBlocks;
    union {
        struct {
            uint32  flags;
            uint32  size;
            char    name[32];
            char    data[1];
        } firstBlockRec;
        struct {
            char    data[1];
        } nextBlockRec;
    } varBlock;
} AssetBlockHeader, *AssetBlockPtr;

ErrNbr     AddAsset(Handle h, AssetType type, AssetID id, StringPtr name);
ErrNbr     AssetError(void);
Boolean    AssetExists(AssetType type, AssetID id);
Boolean    AssetExistsWithCRC(AssetType type, AssetID id, uint32 crc);
Boolean    AssetIsDuplicate(Handle h);
ErrNbr     ChangedAsset(Handle h);
ErrNbr     CloseAssetFile(FileHandle refNum);
void       CompressAssetNames(void);
uint32     ComputeCRC(Ptr p, uint32 len);
sint32     CountAssets(AssetType type);
sint32     CountAssetTypes(void);
FileHandle CreateAndOpenTempFile(FSSpec *seed);
FileHandle CurAssetFile(void);
ErrNbr     DetachAsset(Handle h);
Boolean    FindAssetByHandle(Handle rHandle, AssetTypeRec **att, AssetRec **app);
AssetRec  *FindAssetRec(AssetType type, AssetID id);
AssetRec  *FindAssetRecByIndex(AssetType type, sint32 idx);
AssetRec  *FindAssetRecByName(AssetType type, StringPtr name);
AssetRec  *FindAssetRecWithCRC(AssetType type, AssetID id, uint32 crc);
Handle     GetAsset(AssetType type, AssetID id);
Handle     GetAssetByName(AssetType type, StringPtr name);
uint32     GetAssetCRC(Handle h);
ErrNbr     GetAssetInfo(Handle h, AssetType *type, AssetID *id, StringPtr name);
ErrNbr     GetAssetNameWithCRC(AssetType type, AssetID id, uint32 crc, StringPtr name);
void       GetAssetTime(time_t *secs);
void       ResetAssetTime(void);
Handle     GetAssetWithCRC(AssetType type, AssetID id, uint32 crc);
sint32     GetHandleSize(Handle h);
Handle     GetIndAsset(AssetType type, sint32 nbr);
AssetType  GetIndAssetType(sint32 nbr);
Boolean    IsBadProp(Ptr p);
Handle     LoadAsset(AssetRec huge *ap);
ErrNbr     LoadAssetMap(FileHandle refNum);
ErrNbr     NewAssetFile(FSSpec *sfFile, FileHandle *refNum);
ErrNbr     NewAssetFileRec(FileHandle refNum);
ErrNbr     OpenAssetFile(FSSpec *sfFile, FileHandle *refNum);
ErrNbr     ReleaseAsset(Handle h);
ErrNbr     ReleaseAssetWithCRC(Handle h, AssetType type, AssetID id, uint32 crc);
ErrNbr     RmveAsset(Handle rHandle);
ErrNbr     ReleaseAssets(AssetType assetType);
ErrNbr     SetAssetCRC(Handle h, uint32 crc);
ErrNbr     SetAssetInfo(Handle h, AssetID id, StringPtr name);
AssetID    UniqueAssetID(AssetType type, AssetID minID);
ErrNbr     UpdateAssetFile(void);
ErrNbr     UseAssetFile(FileHandle refNum);
ErrNbr     UseTempAssetFile(void);
ErrNbr     WriteAsset(AssetRec *ap);
ErrNbr     WriteAssetFile(void);
ErrNbr     WriteAssetMap(FileHandle oRefNum);


#if PRP_BINARY_SEARCH
sint32 GetAssetIndexById(AssetType type, AssetID id);
ErrNbr SortAssetsByID(void);
#else
ErrNbr SortAssetsByUsage(void);
#endif


#ifdef unix
sint32 AddAssetHandle(Handle h);
void   ClearAssetHandle(sint32 handleID);
Handle GetAssetHandle(sint32 handleID);
#define NullAssetHandle     0
#else
#ifdef DEBUG_ASSETS
Handle AddAssetHandleDB(Handle h, char *fileName, int lineNumber);
void   ClearAssetHandleDB(Handle handleID, char *fileName, int lineNumber);
Handle GetAssetHandleDB(Handle handleID, char *fileName, int lineNumber);

#define AddAssetHandle(h)   AddAssetHandleDB(h, __FILE__, __LINE__)
#define ClearAssetHandle(h) ClearAssetHandleDB(h, __FILE__, __LINE__)
#define GetAssetHandle(h)   GetAssetHandleDB(h, __FILE__, __LINE__)
#else
#define AddAssetHandle(h)   h
#define ClearAssetHandle(h) DisposeHandle(h)
#define GetAssetHandle(h)   h
#endif
#define NullAssetHandle     NULL
#endif

#endif /* __MASSETS__ */
