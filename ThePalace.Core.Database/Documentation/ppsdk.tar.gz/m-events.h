/*
 * m-events.h
 *
 * Defines for the Palace protocol and client/server internal events.
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __MEVENTS__
#define __MEVENTS__

#ifdef unix
#include <ppsdk/config.h>
#endif

/* Packet header tag */
#define PacketTag           0x506c506b /* 'PlPk' */

/* These are used by the Macintosh version to identify palace packets amongst
   other high level events. */
#define ServerEventID       0x6d537276 /* 'mSrv' */
#define UserEventID         0x6d557372 /* 'mUsr' */

/*
  These are the message ID#s used for the Palace protocol. Note that messages
  are stored numerically so as to allow the native systems to detect which
  byte order is in effect.  When the server sends the initial TIYID message,
  it will be received "backwards" by the client if the server is using a
  different byte order.  In this case, the client should initiate byte order
  swapping of packets.
*/

/*         Message         Number       String  Description */

#define MSG_ALTLOGONREPLY  0x72657032 /* 'rep2' */
#define MSG_ASSETNEW       0x61417374 /* 'aAst' Acknowledge Asset - provides
                                                type and ID#, sent in response
                                                to user->'rAst' */
#define MSG_ASSETQUERY     0x71417374 /* 'qAst' */
#define MSG_ASSETREGI      0x72417374 /* 'rAst' */
#define MSG_ASSETSEND      0x73417374 /* 'sAst' Send Asset - provides asset to
                                                user. */

#define MSG_AUTHENTICATE   0x61757468 /* 'auth' */
#define MSG_AUTHRESPONSE   0x61757472 /* 'autr' */
#define MSG_AVATARFLAGS    0x66417661 /* 'fAva' */
#define MSG_AVATARQUERY    0x71417661 /* 'qAva' */
#define MSG_AVATARSEND     0x73417661 /* 'sAva' */

#define MSG_BADAUTH        0x6662646e /* 'fbdn' */
#define MSG_BLOWTHRU       0x626c6f77 /* 'blow' */
#define MSG_DISPLAYURL     0x6475726c /* 'durl' */
#define MSG_DIYIT          0x72796974 /* 'ryit' */
#define MSG_DOORLOCK       0x6c6f636b /* 'lock' Lock Door */

#define MSG_DOORUNLOCK     0x756e6c6f /* 'unlo' Unlock Door */
#define MSG_DRAW           0x64726177 /* 'draw' Add drawing command to object
                                                layer (or blow up) */
#define MSG_EXTENDEDINFO   0x73496e66 /* 'sInf' Extends server info packet */
#define MSG_FILENOTFND     0x666e6665 /* 'fnfe' File not found error */
#define MSG_FILEQUERY      0x7146696c /* 'qFil' */

#define MSG_FILESEND       0x7346696c /* 'sFil' */
#define MSG_GETORSETPREFS  0x70726566 /* 'pref' */
#define MSG_GETORSETPREFSREPLY 0x70726672 /*'prfr'*/
#define MSG_GETUSERIDENTITY 0x75696471 /* 'uidq' */
#define MSG_GETUSERIDENTITYREPLY 0x75696472 /* 'uidr' */

#define MSG_GMSG           0x676d7367 /* 'gmsg' */
#define MSG_HTTPSERVER     0x48545450 /* 'HTTP' HTTP Server URL */
#define MSG_INITCONNECTION 0x634c6f67 /* 'cLog' */ /* XXX obsolete?? */
#define MSG_KILLUSER       0x6b696c6c /* 'kill' */
#define MSG_LISTOFALLROOMS 0x724c7374 /* 'rLst' */

#define MSG_LISTOFALLUSERS 0x754c7374 /* 'uLst' */
#define MSG_LOGOFF         0x62796520 /* 'bye ' Sign off */
#define MSG_LOGON          0x72656769 /* 'regi' Sign on */
#define MSG_NAVERROR       0x73457272 /* 'sErr' Server error, such as
                                                navigation refused */
#define MSG_NOOP           0x4e4f4f50 /* 'NOOP' No operation; no response */

#define MSG_PICTDEL        0x46505371 /* 'FPSq' */
#define MSG_PICTMOVE       0x704c6f63 /* 'pLoc' */
#define MSG_PICTNEW        0x6e506374 /* 'nPct' */
#define MSG_PICTSETDESC    0x73506374 /* 'sPct' */
#define MSG_PING           0x70696e67 /* 'ping' See if server is there */

#define MSG_PONG           0x706f6e67 /* 'pong' Response to ping */
#define MSG_PROPDEL        0x64507270 /* 'dPrp' */
#define MSG_PROPMOVE       0x6d507270 /* 'mPrp' */
#define MSG_PROPNEW        0x6e507270 /* 'nPrp' */
#define MSG_PROPSETDESC    0x73507270 /* 'sPrp' */

#define MSG_RESPORT        0x72657370 /* 'resp' For HTTP tunneling */
#define MSG_RMSG           0x726d7367 /* 'rmsg' */
#define MSG_ROOMDESC       0x726f6f6d /* 'room' Current Room Description */
#define MSG_ROOMDESCEND    0x656e6472 /* 'endr' End Room Description */
#define MSG_ROOMGOTO       0x6e617652 /* 'navR' Navigation to new room */

#define MSG_ROOMNEW        0x6e526f6d /* 'nRom' New room request */
#define MSG_ROOMSETDESC    0x73526f6d /* 'sRom' Set room description */
#define MSG_SERVERDOWN     0x646f776e /* 'down' Server is going down */
#define MSG_SERVERINFO     0x73696e66 /* 'sinf' Server Info Packet */
#define MSG_SERVERUP       0x696e6974 /* 'init' Server is going up */

#define MSG_SMSG           0x736d7367 /* 'smsg' */
#define MSG_SPOTDEL        0x6f705364 /* 'opSd' Delete Spot */
#define MSG_SPOTMOVE       0x636f4c73 /* 'coLs' Update spot location */
#define MSG_SPOTNEW        0x6f70536e /* 'opSn' New spot request */
#define MSG_SPOTSETDESC    0x6f705373 /* 'opSs' Set spot description */

#define MSG_SPOTSTATE      0x73537461 /* 'sSta' Update state (and possibly
                                                picture) for hotspot */
#define MSG_SUPERUSER      0x73757372 /* 'susr' */
#define MSG_TALK           0x74616c6b /* 'talk' Talk */
#define MSG_TIMYID         0x74696d79 /* 'timy' This is my ID; for reconnecting
                                                dropped HTTP users */
#define MSG_TIYID          0x74697972 /* 'tiyr' This is your id# */

#define MSG_TROPSER        0x70736572 /* 'pser' For HTTP tunneling */
#define MSG_USERCOLOR      0x75737243 /* 'usrC' Change user parameters */
#define MSG_USERDESC       0x75737244 /* 'usrD' */
#define MSG_USERENTER      0x77707273 /* 'wprs' New Person in Current Room */
#define MSG_USEREXIT       0x65707273 /* 'eprs' Person is leaving your Room */

#define MSG_USERFACE       0x75737246 /* 'usrF' Change user face */
#define MSG_USERLIST       0x72707273 /* 'rprs' Room Person Descriptions */
#define MSG_USERLOG        0x6c6f6720 /* 'log ' User logged on */
#define MSG_USERMOVE       0x754c6f63 /* 'uLoc' User has changed position */
#define MSG_USERNAME       0x7573724e /* 'usrN' New user name */

#define MSG_USERNEW        0x6e707273 /* 'nprs' */
#define MSG_USERPROP       0x75737250 /* 'usrP' Change user prop */
#define MSG_USERSTATUS     0x75537461 /* 'uSta' */
#define MSG_VERSION        0x76657273 /* 'vers' Mansion Version Number */
#define MSG_WHISPER        0x77686973 /* 'whis' Whisper */

#define MSG_WMSG           0x776d7367 /* 'wmsg' */
#define MSG_XTALK          0x78746c6b /* 'xtlk' */
#define MSG_XWHISPER       0x78776973 /* 'xwis' */

enum {
    SE_InternalError,
    SE_RoomUnknown,
    SE_RoomFull,
    SE_RoomClosed,
    SE_CantAuthor,
    SE_PalaceFull
};

/*****************************************************************************/

#endif /* __MEVENTS__ */
