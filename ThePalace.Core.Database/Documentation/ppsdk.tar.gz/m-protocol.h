/*
 * m-protocol.h
 *
 * Declarations of structs and types associated with the Palace client/server
 * message protocol.
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __PROTOCOL__
#define __PROTOCOL__

#include <ppsdk/mansion.h>

/**
 * Generic form of a client/server message.
 */
typedef struct {
    uint32  eventType; /* 32-bit opcode */
    uint32  length;    /* length of message body */
    sint32  refNum;    /* arbitrary integer operand */
    uint32  msg;       /* message body; actually <length> bytes */
} ClientMsg;

typedef struct {
    uint32  eventType; /* 32-bit opcode */
    uint32  length;    /* length of message body */
    sint32  refNum;    /* arbitrary integer operand */
} ClientMsgHeader;


/* The following string types are all represented by arrays of char, but have
   different internal structure. Though we declare them as length 4 here (for
   alignment cleanliness, given that we can't declare them with length 0 in
   all compilers), they are actually variable-length. */
typedef char CLangString[4]; /* C string: length indicated by nul terminator */
typedef char XString[4]; /* Encrypted C string: length stored in first two
                            bytes; length includes the two length bytes
                            themselves plus a nul terminator that is visible
                            only after decryption */
typedef unsigned char PString[4]; /* Pascal string: length stored in first
                            byte; length does not include length byte itself */

/*
 * The various client/server messages.
 */

typedef struct {
    AuxRegistrationRec rec;
} ClientMsg_altLogonReply PACKED;

typedef struct {
    AssetType       type;
    AssetSpec       spec;
} ClientMsg_assetQuery PACKED;

typedef struct {
    uint32 flags;
    uint32 size;
    Str31  name;
} AssetDescriptor PACKED;

typedef struct {
    AssetType       type;
    AssetSpec       spec;
    uint32          blockSize;
    sint32          blockOffset;
    uint16          blockNbr;
    uint16          nbrBlocks;
    union {
        struct {
            AssetDescriptor desc;
            char            data[1]; /* actually, [blockSize] */
        } firstBlockRec;
        struct {
            char            data[1]; /* actually, [blockSize] */
        } nextBlockRec;
    } varBlock;
} ClientMsg_assetSend PACKED;

/*
typedef struct {
} ClientMsg_authenticate PACKED;
*/

typedef struct {
    PString         nameAndPassword;
} ClientMsg_authResponse PACKED;

typedef struct {
    uint16      avatarFlags;
} ClientMsg_avatarFlags;

typedef struct {
    uint8       hash[AVATAR_HASH_LEN];
} ClientMsg_avatarQuery;

typedef struct {
    uint8       hash[AVATAR_HASH_LEN];
    uint32      flags;
#define AVATAR_SEND_DATA 0
#define AVATAR_SEND_URL  1
    uint32      dataSize;
    /* uint8       data[dataSize] */
} ClientMsg_avatarSend;

/*
typedef struct {
} ClientMsg_badAuth PACKED;
*/

typedef struct {
    uint32          flags;
    sint32          nbrUsers;
    UserID          userIDs[1]; /* actually, [nbrUsers], but iff nbrUsers>=0 */
    /* uint32          pluginTag; */
    /* uint8  embedded[]; */
} ClientMsg_blowThru_toServer PACKED;

typedef struct {
    /* uint32          pluginTag; */
    uint8           embedded[4];
} ClientMsg_blowThru_toClient PACKED;

typedef struct {
    CLangString     url;
} ClientMsg_displayURL PACKED;

typedef struct {
    RoomID          roomID;
    HotspotID       doorID;
} ClientMsg_doorLock PACKED;

typedef struct {
    DrawRecord      command;
} ClientMsg_draw PACKED;

typedef struct {
    sint32 id;
    sint32 length;
    uint8  buf[4]; /* actually [length] */
} ExtendedInfo PACKED;

typedef struct {
    sint32 id;
    sint32 length;
} ExtendedInfoHeader PACKED;

typedef struct {
    uint32          flags;
    ExtendedInfo    info[1]; /* actually variable length */
} ClientMsg_extendedInfo_request PACKED;

typedef struct {
    ExtendedInfo    info[1]; /* actually variable length */
} ClientMsg_extendedInfo_response PACKED;

typedef struct {
    PString         filename;
} ClientMsg_fileNotFnd PACKED;

typedef struct {
    PString         filename;
} ClientMsg_fileQuery PACKED;

typedef struct {
    uint32 size;
    Str63  name;
} FileDescriptor PACKED;

typedef struct {
    sint32          transactionID;
    uint32          blockSize;
    uint16          blockNbr;
    uint16          nbrBlocks;
    FileDescriptor  desc;
    uint8           data[1]; /* actually [blockSize] */
} ClientMsg_fileSend PACKED;

#define GOD_HASH_LEN (20)
#define GOD_SALT_LEN (8)    

typedef struct {
    uint8 godPasswordHash[GOD_HASH_LEN];
    uint8 godPasswordSalt[GOD_SALT_LEN];
    uint32 numPrefs;
    CLangString prefs;
} ClientMsg_getOrSetPrefs_request PACKED;

typedef struct {
    uint8 godPasswordHash[GOD_HASH_LEN];
    uint8 godPasswordSalt[GOD_SALT_LEN];
    uint32 numPrefs;
} ClientMsg_getOrSetPrefs_requestHeader PACKED;

typedef struct {
    uint32 numPrefs;
    uint32 numErrors;
    CLangString prefsAndErrors;
} ClientMsg_getOrSetPrefs_reply PACKED;

typedef struct {
    uint32 numPrefs;
    uint32 numErrors;
} ClientMsg_getOrSetPrefs_replyHeader PACKED;

/*
typedef struct {
} ClientMsg_getUserIdentity_request PACKED;
*/

typedef struct {
    CLangString     identity;
} ClientMsg_getUserIdentity_response PACKED;

typedef struct {
    CLangString     text;
} ClientMsg_gMsg PACKED;

typedef struct {
    CLangString     url;
} ClientMsg_HTTPServer PACKED;

typedef struct {
    UserID          targetID;
} ClientMsg_killUser PACKED;

/*
typedef struct {
} ClientMsg_listOfAllRooms_request PACKED;
*/

typedef struct {
    RoomListRec     rooms[1]; /* actually variable length */
} ClientMsg_listOfAllRooms_response PACKED;

/*
typedef struct {
} ClientMsg_listOfAllUsers_request PACKED;
*/

typedef struct {
    UserListRec     users[1]; /* actually variable length */
} ClientMsg_listOfAllUsers_response PACKED;

/*
typedef struct {
} ClientMsg_logoff_request PACKED;
*/

typedef struct {
    sint32          nbrUsers;
} ClientMsg_logoff_notify PACKED;

typedef struct {
    AuxRegistrationRec rec;
} ClientMsg_logon PACKED;

/*
typedef struct {
} ClientMsg_navError PACKED;

typedef struct {
} ClientMsg_noOp PACKED;
*/

typedef struct {
    RoomID          roomID;
    HotspotID       spotID;
    Point           pos;
} ClientMsg_pictMove PACKED;

/*
typedef struct {
} ClientMsg_ping PACKED;

typedef struct {
} ClientMsg_pong PACKED;
*/

typedef struct {
    sint32          propNum;
} ClientMsg_propDel PACKED;

typedef struct {
    sint32          propNum;
    Point           pos;
} ClientMsg_propMove PACKED;

typedef struct {
    AssetSpec       propSpec;
    Point           pos;
} ClientMsg_propNew PACKED;

typedef struct {
    AssetSpec       propSpec;
    Point           pos;
    sint16          avatarType;
    uint16          avatarFlags;
    uint8           hash[AVATAR_HASH_LEN];
} ClientMsg_propNewExtended PACKED;

typedef struct {
    CLangString     text;
} ClientMsg_rMsg PACKED;

typedef struct {
    RoomRec         rec;
} ClientMsg_roomDesc PACKED;

/*
typedef struct {
} ClientMsg_roomDescEnd PACKED;
*/

typedef struct {
    RoomID          dest;
} ClientMsg_roomGoto PACKED;

/*
typedef struct {
} ClientMsg_roomNew PACKED;
*/

typedef struct {
    RoomRec         rec;
} ClientMsg_roomSetDesc PACKED;

typedef struct {
    CLangString     whyMessage;
} ClientMsg_serverDown PACKED;

typedef struct {
    sint32          serverPermissions;
    Str63           serverName;
    uint32          serverOptions;
    uint32          ulUploadCaps;
    uint32          ulDownloadCaps;
} ClientMsg_serverInfo PACKED;

typedef struct {
    CLangString     text;
} ClientMsg_sMsg PACKED;

typedef struct {
    HotspotID       spotID;
} ClientMsg_spotDel PACKED;

typedef struct {
    RoomID          roomID;
    HotspotID       spotID;
    Point           pos;
} ClientMsg_spotMove PACKED;

/*
typedef struct {
} ClientMsg_spotNew PACKED;
*/

typedef struct {
    RoomID          roomID;
    HotspotID       spotID;
    sint16          state;
} ClientMsg_spotState PACKED;

typedef struct {
    PString         password;
} ClientMsg_superuser PACKED;

typedef struct {
    CLangString     text;
} ClientMsg_talk PACKED;

/*
typedef struct {
} ClientMsg_tiyid PACKED;
*/

typedef struct {
    sint16          colorNbr;
} ClientMsg_userColor PACKED;

typedef struct {
    sint16          faceNbr;
    sint16          colorNbr;
    sint32          nbrProps;
    AssetSpec       props[1]; /* actually [nbrProps] */
} ClientMsg_userDesc PACKED;

typedef struct {
    sint16          faceNbr;
    sint16          colorNbr;
    sint32          nbrProps;   /* should be 0 */
    sint16          avatarType; /* should be AT_AVATAR */
    uint16          avatarFlags;
    uint8           hash[AVATAR_HASH_LEN];
} ClientMsg_userDesc_avatar PACKED;

typedef struct {
    sint16          faceNbr;
    sint16          colorNbr;
    sint32          nbrProps;
} ClientMsg_userDesc_header PACKED;

typedef struct {
    sint16          faceNbr;
    sint16          colorNbr;
    sint32          nbrProps;
    AssetSpec       props[MaxUserProps]; /* actually [nbrProps] */
} ClientMsg_userDesc_full PACKED;

/*
typedef struct {
} ClientMsg_userExit PACKED;
*/

typedef struct {
    sint16          faceNbr;
} ClientMsg_userFace PACKED;

typedef struct {
    UserRec         users[1]; /* actually variable length */
} ClientMsg_userList PACKED;

typedef struct {
    sint32          nbrUsers;
} ClientMsg_userLog PACKED;

typedef struct {
    Point           pos;
} ClientMsg_userMove PACKED;

typedef struct {
    PString         name;
} ClientMsg_userName PACKED;

typedef struct {
    UserRec         newUser;
} ClientMsg_userNew PACKED;

typedef struct {
    sint32          nbrProps;
    AssetSpec       props[1]; /* actually [nbrProps] */
} ClientMsg_userProp PACKED;

typedef struct {
    sint32          nbrProps;   /* should be 0 */
    sint16          avatarType; /* should be AT_AVATAR */
    uint16          avatarFlags;
    uint8           hash[AVATAR_HASH_LEN];
} ClientMsg_userProp_avatar PACKED;

typedef struct {
    sint32          nbrProps;
} ClientMsg_userProp_header PACKED;

typedef struct {
    sint32          nbrProps;
    AssetSpec       props[MaxUserProps]; /* actually [nbrProps] */
} ClientMsg_userProp_full PACKED;

typedef struct {
    uint16          flags;
} ClientMsg_userStatus PACKED;

/*
typedef struct {
} ClientMsg_version PACKED;
*/

typedef struct {
    UserID          target;
    CLangString     text;
} ClientMsg_whisper_request PACKED;

typedef struct {
    UserID          target;
} ClientMsg_whisper_request_header PACKED;

typedef struct {
    CLangString     text;
} ClientMsg_whisper_action PACKED;

typedef struct {
    XString         text;
} ClientMsg_xTalk PACKED;

typedef struct {
    UserID          target;
    XString         text;
} ClientMsg_xWhisper_request PACKED;

typedef struct {
    UserID          target;
} ClientMsg_xWhisper_request_header PACKED;

typedef struct {
    XString         text;
} ClientMsg_xWhisper_action PACKED;

#endif /* __PROTOCOL__ */
