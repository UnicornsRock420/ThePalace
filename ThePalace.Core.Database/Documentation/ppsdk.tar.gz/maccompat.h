/*
 * maccompat.h
 *
 * Types and structs for the Macintosh-compatibility package.
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __MACCOMPAT__
#define __MACCOMPAT__

#include <string.h>

typedef sint16          Boolean;
typedef char           *Ptr;
typedef Ptr            *Handle;
typedef unsigned char  *StringPtr;
typedef unsigned char   Str3[4];
typedef unsigned char   Str7[8];
typedef unsigned char   Str15[16];
typedef unsigned char   Str31[32];
typedef unsigned char   Str63[64];
typedef unsigned char   Str127[128];
typedef unsigned char   Str255[256];
typedef sint16          OSErr;
typedef uint32          OSType;
typedef sint32          Size;

typedef struct {
    sint16  v;
    sint16  h;
} Point;

typedef struct {
    sint16  top;
    sint16  left;
    sint16  bottom;
    sint16  right;
} Rect;

typedef struct {
    sint16  vRefNum;
    sint32  parID;
    Str255  name;
} FSSpec;

#define false 0
#define true  !false

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE  !FALSE
#endif

#ifndef NULL
#define NULL           0
#endif


/* MacOS error codes that we actually use */
#define noErr          0
#define fnfErr       -43
#define memFullErr  -108
#define resNotFound -192


/* Function prototypes for emulated MacOS Toolbox calls */

/* Memory */

#if NOMEMMOVE
void memmove(char *dst, char *src, size_t length);
#endif
#define BlockMove(src, dst, size)  memmove(dst, src, size)
void   DisposeHandle(Handle h);
void   DisposePtr(void *ptr);
Size   GetHandleSize(Handle h);
char   HGetState(Handle h);
void   HLock(Handle h);
void   HSetState(Handle h, char tagByte);
void   HUnlock(Handle h);
OSErr  HandToHand(Handle *h);
OSErr  MemError(void);
Handle NewHandle(Size size);
Handle NewHandleClear(Size size);
Ptr    NewPtr(uint32 size);
Ptr    NewPtrClear(uint32 size);
OSErr  ResizeHandle(Handle h, Size newSize);
void   SetHandleSize(Handle h, Size newSize);


/* Files */

/* Position modes for SetFPos, aka seek */
#define fsAtMark       0
#define fsFromStart    1
#define fsFromLEOF     2
#define fsFromMark     3

/* File permission modes for FSpOpenDF */
#define fsCurPerm      0
#define fsRdPerm       1
#define fsWrPerm       2
#define fsRdWrPerm     3
#define fsRdWrShPerm   4

OSErr Create(StringPtr fName, short vRefNum, OSType creator, OSType fileType);
OSErr FSClose(short fRefNum);
OSErr FSDelete(StringPtr fName, short volNum);
OSErr FSOpen(StringPtr fName, short volNum, short *fRefNum);
OSErr FSRead(short fRefNum, sint32 *inOutCount, Ptr buffer);
OSErr FSWrite(short fRefNum, sint32 *inOutCount, Ptr buffer);
OSErr FSpCreate(FSSpec *spec, OSType creator, OSType fileType, short scrTag);
OSErr FSpDelete(FSSpec *spec);
OSErr FSpOpenDF(FSSpec *spec, char permission, short *refNum);
OSErr FSpRename(FSSpec *spec, StringPtr nName);
OSErr FlushFile(short refNum);
OSErr FlushVol(StringPtr vName, short volNum);
OSErr GetEOF(short fRefNum, sint32 *fileSize);
OSErr Rename(StringPtr fName, short vRefNum, StringPtr newName);
OSErr SetEOF(short fRefNum, uint32 fileSize);
OSErr SetFPos(short fRefNum, short posMode, uint32 posOffset);


/* Graphics */

Boolean EqualPt(Point a, Point b);


/* Miscellaneous */

#ifndef _WINDOWS
void CtoPstr(char *str);
void GetDateTime(time_t *secs);
void PtoCstr(StringPtr str);
void SysBeep(short dmy);
#endif

#endif /* __MACCOMPAT__ */
