/*
 * mansion.h
 *
 * Common declarations for Palace client and server
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __MANSION__
#define __MANSION__

#ifndef __GNUC__
#ifndef __attribute__
#define __attribute__(foo)
#endif
#endif

#define PACKED  __attribute__((packed))

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>
#include <math.h>
#include <ppsdk/local.h>
#include <ppsdk/m-events.h>
#include <ppsdk/m-assets.h>

/* For declaring ordinary server functions which are "exported" as part of the
   server plugin API */
#ifdef macintosh
#define SERVER_PLUGIN_API __declspec(export)
#else
#define SERVER_PLUGIN_API
#endif

#if !TARGET_OS_MAC  /* If this is mac these are defined in compileflags.h */
#define TIMEBOMB        0           /* clear before final release!! */
#define DEBUG           1           /* clear before final release!! */
#define RELEASE         0           /* set for final release!! */
#else
#include <MacTCP.h>
#endif

#define MansionVersion  0x00010016

#define MaxHotPts         32
#define MaxPictureRecs    64
#define RoomWidth        512
#define RoomHeight       384
#define NbrColors         16
#define MaxUserProps       9
#define MinReservedProp    0x1F4
#define MaxReservedProp    0x500
#define MinGuestRoom       0
#define MaxGuestRoom     199
#define MaxPeoplePerRoom  64

/*****************************************************************************/

/** Connection types */
enum {
    C_None,
    C_AppleTalk,
    C_IRCTCP,
    C_IRCSerial,
    C_PalaceTCP,
    C_PalaceTelnet,
    C_DDE,
    C_IPX,
    C_WinSock,
    C_BerkSockets,
    C_MacTCP,
    C_IRC,
    C_Serial,
    C_CompuServe,
    C_PalaceUDP,
    C_PalaceHTTP,
    C_Phantom,
    C_NbrConnectionTypes
};
      
/** Hotspot types */
enum {
    HS_Normal,
    HS_Door,
    HS_ShutableDoor,
    HS_LockableDoor,
    HS_Bolt,
    HS_NavArea
};

/** Hotspot States */
#define HS_Unlock   0
#define HS_Lock     1

/** Draw Commands */
enum {
    DC_Path,
    DC_Shape,
    DC_Text,
    DC_Detonate,
    DC_Delete,
    DC_Ellipse,
    DC_NbrDrawCmds
};

/** Shape Types */
enum {
    ST_Rect,
    ST_Oval
};

/** Face Types */
enum {
    FACE_Closed,
    FACE_Smile,
    FACE_TiltDown,
    FACE_Talk,
    FACE_WinkLeft,
    FACE_Normal,
    FACE_WinkRight,
    FACE_TiltLeft,
    FACE_TiltUp,
    FACE_TiltRight,
    FACE_Sad,
    FACE_Blotto,
    FACE_Angry
};

/** Values whyKilled */
enum {
    K_Unknown,
    K_LoggedOff,
    K_CommError,
    K_Flood,
    K_KilledByPlayer,
    K_ServerDown,
    K_Unresponsive,
    K_KilledBySysop,
    K_ServerFull,
    K_InvalidSerialNumber,
    K_DuplicateUser,
    K_DeathPenaltyActive,
    K_Banished,
    K_BanishKill,
    K_NoGuests,
    K_DemoExpired,
    K_Verbose
};

/*****************************************************************************/

typedef sint16  Offset;         /* An offset into a variable-length record */
typedef uint32  UserID;         /* Index number amongst logged on users */
typedef sint16  RoomID;         /* Index number amongst rooms */
typedef sint16  HotspotID;
typedef uint32  ClientID; /* Client serial# from registration code */

typedef AssetID ObjectID;       /* deprecated, use AssetID */
typedef UserID  PersonID;       /* deprecated, use UserID */

#define AVATAR_HASH_LEN 20

typedef struct {
    sint32  refCon;
    sint16  eventType;
    sint16  scriptTextOfst;
} EventHandlerRec, *EventHandlerPtr;

typedef struct {
    sint32  refCon;
    sint16  picID;
    Offset  picNameOfst;
    sint16  transColor;
    sint16  reserved;
} PictureRec PACKED, *PictureRecPtr;

typedef struct {
    sint16  pictID;
    sint16  reserved;
    Point   picLoc;             /* offset from hotspot->loc */
} StateRec PACKED, *StateRecPtr;

typedef struct {
    Offset  nextOfst;
    sint16  reserved;
} LLRec, *LLPtr;

/** Loose prop flags */
#define LPF_Extended    0x00000001  /* Uses extended record */

typedef struct {
    LLRec       link;           /* Link to next Loose Prop */
    AssetSpec   propSpec;
    uint32      flags;
    sint32      refCon;
    Point       loc;
} LPropRec, *LPropPtr;

typedef struct {
    LLRec       link;           /* Link to next Loose Prop */
    AssetSpec   propSpec;
    uint32      flags;
    sint32      refCon;
    Point       loc;
    sint16      avatarType;
    uint16      avatarFlags;
    uint8       hash[AVATAR_HASH_LEN];
} LPropRecExtended;

typedef struct {
    LLRec      link;
    sint16     drawCmd;
    uint16     cmdLength;
    Offset     dataOfst;        /* Points or TextRecord */
} DrawRecord, *DrawRecPtr;

typedef struct {
    uint16     red;
    uint16     green;
    uint16     blue;
} DrawRGBColor PACKED;

typedef struct { /* drawCmd == DC_Path */
    sint16     penSize;
    sint16     nbrPts;
    DrawRGBColor foreColor;
    Point      anchorPt;
    Point      points[1];       /* actually [nbrPts] */
} DrawRecordExt_path PACKED;

typedef struct { /* drawCmd == DC_Shape */
    sint16     shapeType;
    sint16     penSize;
    DrawRGBColor foreColor;
    DrawRGBColor backColor;
    sint8      fillShape;
    sint8      pattern;
    Rect       bounds;
} DrawRecordExt_shape PACKED;

typedef struct { /* drawCmd == DC_Ellipse */
    sint16     penSize;
    sint16     ptCount;         /* always 2 (?) */
    DrawRGBColor foreColor;
    Rect       bounds;
} DrawRecordExt_ellipse PACKED;

/** Hotspot flags */
#define HS_Draggable    0x0001
#define HS_DontMoveHere 0x0002
#define HS_Invisible    0x0004
#define HS_ShowName     0x0008
#define HS_ShowFrame    0x0010
#define HS_Shadow       0x0020
#define HS_Fill         0x0040
#define HS_Forbidden    0x0080
#define HS_Mandatory    0x0100
#define HS_LandingPad   0x0200

typedef struct {
    uint32      scriptEventMask;
    uint32      flags;
    uint32      secureInfo;     /* unused at the moment */
    sint32      refCon;         /* ditto */
    Point       loc;            /* Computed automatically */
    sint16      id;             /* may not correspond to order */
    sint16      dest;           /* or destDoor */
    uint16      nbrPts;
    Offset      ptsOfst;
    sint16      type;           /* 0 = navRgn,  1 = door, 2 = lock */
    sint16      groupID;
    uint16      nbrScripts;
    Offset      scriptRecOfst;
    sint16      state;
    uint16      nbrStates;
    Offset      stateRecOfst;
    Offset      nameOfst;
    Offset      scriptTextOfst;
    sint16      alignReserved;
} Hotspot, *HotspotPtr;

/** User flags */
#define U_SuperUser         0x0001  /* Wizard */
#define U_God               0x0002  /* Sysop level access */
#define U_Kill              0x0004  /* Local flag for killing */
#define U_Guest             0x0008  /* Local guest flag */
#define U_Banished          0x0010
#define U_Penalized         0x0020
#define U_CommError         0x0040
#define U_Gag               0x0080
#define U_Pin               0x0100
#define U_Hide              0x0200
#define U_RejectESP         0x0400
#define U_RejectPrivate     0x0800
#define U_PropGag           0x1000
#define U_ExpectAuthResp    0x2000
#define U_Shadow            0x4000

#define AT_PROP   0
#define AT_AVATAR 1

#define AF_HorizontalFlip    0x0001
#define AF_VerticalFlip      0x0002
#define AF_InhibitAnimation  0x0004
#define AF_ValidFlags        0x0007

typedef struct UserRec {
    UserID      userID;     /* Unique User ID */
    Point       roomPos;    /* Applies to gObject */
    AssetSpec   propSpec[MaxUserProps];
    RoomID      roomID;     /* Applies to socket, not gObject */
    sint16      faceNbr;    /* Applies to Person (gObject subtype) */
    sint16      colorNbr;
    sint16      avatarType;
    uint16      avatarFlags;
    uint16      nbrProps;
    Str31       name;       /* Applies to Person */
} UserRec PACKED, *UserRecPtr;

typedef struct {
    UserID      userID;     /* Unique User ID */
    Point       roomPos;    /* Applies to gObject */
    uint8       filler[52];
    uint8       hash[AVATAR_HASH_LEN];
    RoomID      roomID;     /* Applies to socket, not gObject */
    sint16      faceNbr;    /* Applies to Person (gObject subtype) */
    sint16      colorNbr;
    sint16      avatarType;
    uint16      avatarFlags;
    uint16      nbrProps;
    Str31       name;       /* Applies to Person */
} UserRecAvatar;

/** Room flags */
#define RF_AuthorLocked     0x0001      /* Room is security-locked by author */
#define RF_Private          0x0002      /* Room is private */
#define RF_NoPainting       0x0004      /* No Painting Allowed */
#define RF_Closed           0x0008      /* Room Door has been locked */
#define RF_CyborgFreeZone   0x0010      /* No Cyborgs in this room */
#define RF_Hidden           0x0020      /* doesn't show up in goto list*/
#define RF_NoGuests         0x0040
#define RF_WizardsOnly      0x0080
#define RF_DropZone         0x0100
#define RF_NoLooseProps     0x0200

typedef struct RoomRec {
    uint32          roomFlags;
    sint32          facesID;
    RoomID          roomID;         /* Room Number */
    Offset          roomNameOfst;
    Offset          pictNameOfst;
    Offset          artistNameOfst;
    Offset          passwordOfst;
    uint16          nbrHotspots;    /* Number of hot spots (doors & such) */
    Offset          hotspotOfst;
    uint16          nbrPictures;    /* Number of attached pictures */
    Offset          pictureOfst;
    uint16          nbrDrawCmds;    /* Number of draw commands */
    Offset          firstDrawCmd;
    uint16          nbrPeople;      /* Number of people in room */
    uint16          nbrLProps;      /* Loose Prop Objects */
    Offset          firstLProp;
    sint16          reserved;       /* keep structure 4-byte aligned */
    Offset          lenVars;
    char            varBuf[1];
} RoomRec PACKED, *RoomRecPtr;

typedef struct {
    UserID      userID;
    uint16      flags;
    RoomID      roomID;
    char        name[1];        /* quad aligned pascal string */
} UserListRec PACKED, *UserListPtr;

typedef struct {
    UserID      userID;
    uint16      flags;
    RoomID      roomID;
} UserListRecHeader PACKED;

typedef struct {
    sint32      roomID;         /* NOTE: short stored in long for alignment */
    uint16      flags;
    uint16      nbrUsers;
    char        name[1];        /* quad aligned pascal string */
} RoomListRec PACKED, *RoomListPtr;

typedef struct {
    sint32      roomID;         /* NOTE: short stored in long for alignment */
    uint16      flags;
    uint16      nbrUsers;
} RoomListRecHeader PACKED;

/** Server permissions flags */
#define PM_AllowGuests          0x0001
#define PM_AllowCyborgs         0x0002
#define PM_AllowPainting        0x0004
#define PM_AllowCustomProps     0x0008
#define PM_AllowWizards         0x0010
#define PM_WizardsMayKill       0x0020
#define PM_WizardsMayAuthor     0x0040
#define PM_PlayersMayKill       0x0080
#define PM_CyborgsMayKill       0x0100
#define PM_DeathPenalty         0x0200
#define PM_KillFlooders         0x0800
#define PM_NoSpoofing           0x1000
#define PM_MemberCreatedRooms   0x2000

typedef struct {
    uint32          serverPermissions;  /* Server Permissions */
    unsigned char   serverName[64];     /* Server Name - PString */
    uint32          serverOptions;      /* clients really need this info */
    uint32          ulUploadCaps;       /* see LI_ULCAPS_ defines */
    uint32          ulDownloadCaps;     /* see LI_DLCAPS_ defines */
} ServerInfo, *ServerInfoPtr;

typedef struct {
    uint32  ulMaxProtocolVersion; /* HIWORD is major, LOWORD is minor */
    uint32  ulNegotiatedProtocolVersion;
} ServerVersionInfo, *ServerVersionPtr;

typedef struct {
    uint32   crc;
    uint32   counter;
    Str63    userName;
} LogonInfo, *LogonInfoPtr;

typedef struct {
    uint32  crc;
    uint32  counter;
    Str31   userName;
    Str31   wizPassword;
    uint32  auxFlags;
#define  LI_AUXFLAGS_UnknownMach    0
#define  LI_AUXFLAGS_Mac68k         1
#define  LI_AUXFLAGS_MacPPC         2
#define  LI_AUXFLAGS_Win16          3
#define  LI_AUXFLAGS_Win32          4
#define  LI_AUXFLAGS_Java           5
#define  LI_AUXFLAGS_TPV            6
#define  LI_AUXFLAGS_OSMask         0x0000000F
#define  LI_AUXFLAGS_Authenticate   0x80000000

    uint32  puidCtr;
    uint32  puidCRC;
    uint32  demoElapsed;
    uint32  totalElapsed;
    uint32  demoLimit;
    RoomID  desiredRoom;
    char    reserved[6];

    /* HIWORD is major, LOWORD is minor */
    uint32  ulRequestedProtocolVersion;

    uint32  ulUploadCaps;         /* see LI_ULCAPS_ defines */
#define LI_ULCAPS_ASSETS_PALACE     0x00000001UL
#define LI_ULCAPS_ASSETS_FTP        0x00000002UL
#define LI_ULCAPS_ASSETS_HTTP       0x00000004UL
#define LI_ULCAPS_ASSETS_OTHER      0x00000008UL
#define LI_ULCAPS_FILES_PALACE      0x00000010UL
#define LI_ULCAPS_FILES_FTP         0x00000020UL
#define LI_ULCAPS_FILES_HTTP        0x00000040UL
#define LI_ULCAPS_FILES_OTHER       0x00000080UL
#define LI_ULCAPS_EXTEND_PKT        0x00000100UL

    uint32  ulDownloadCaps;       /* see LI_DLCAPS_ defines */
#define LI_DLCAPS_ASSETS_PALACE     0x00000001UL
#define LI_DLCAPS_ASSETS_FTP        0x00000002UL
#define LI_DLCAPS_ASSETS_HTTP       0x00000004UL
#define LI_DLCAPS_ASSETS_OTHER      0x00000008UL
#define LI_DLCAPS_FILES_PALACE      0x00000010UL
#define LI_DLCAPS_FILES_FTP         0x00000020UL
#define LI_DLCAPS_FILES_HTTP        0x00000040UL
#define LI_DLCAPS_FILES_OTHER       0x00000080UL
#define LI_DLCAPS_FILES_HTTPSrvr    0x00000100UL
#define LI_DLCAPS_EXTEND_PKT        0x00000200UL

    uint32  ul2DEngineCaps;       /* see LI_2DENGINECAP_ defines */
#define LI_2DENGINECAP_PALACE       0x00000001UL
#define LI_2DENGINECAP_DOUBLEBYTE   0x00000002UL

    uint32  ul2DGraphicsCaps;     /* see LI_2DGRAPHCAP_ defines */
#define LI_2DGRAPHCAP_GIF87         0x00000001UL
#define LI_2DGRAPHCAP_GIF89a        0x00000002UL
#define LI_2DGRAPHCAP_JPG           0x00000004UL
#define LI_2DGRAPHCAP_TIFF          0x00000008UL
#define LI_2DGRAPHCAP_TARGA         0x00000010UL
#define LI_2DGRAPHCAP_BMP           0x00000020UL
#define LI_2DGRAPHCAP_PCT           0x00000040UL

    uint32  ul3DEngineCaps;       /* see LI_3DENGINECAP_ defines */
#define LI_3DENGINECAP_VRML1        0x00000001UL
#define LI_3DENGINECAP_VRML2        0x00000002UL

} AuxRegistrationRec PACKED;


typedef struct {
    sint32          transactionID;  /* Made unique by server */
    uint32          blockSize;
    uint16          blockNbr;
    uint16          nbrBlocks;
    union {
        struct {
            uint32  size;
            Str63   name;
            char    data[1];
        } firstBlockRec;
        struct {
            char    data[1];
        } nextBlockRec;
    } varBlock;
} FileBlockHeader, *FileBlockPtr;     /* Used to send files over net */

typedef struct ExtendedInfoRec {
    uint32 flags;
    char   buf[1];
} ExtendedInfoRec, *ExtendedInfoRecPtr;

typedef struct ExtendedInfoString {
    uint32 id;
    uint32 length;
    char   buf[1];
} ExtendedInfoString, *ExtendedInfoStringPtr;

typedef struct ExtendedInfoAvatar {
    uint32 formats;
#define AVFORM_GIF      0x0001
#define AVFORM_JPEG     0x0002
#define AVFORM_PNG99A   0x0004
#define AVFORM_MNG      0x0008
#define AVFORM_FLASH    0x0010
    uint16 maxPayload; /* in kilobytes */
    uint16 maxHeight;
    uint16 maxWidth;
    uint16 reserved;
} ExtendedInfoAvatar;


/** Server info request flags */
#define SI_AVATAR_URL      0x00000001
#define SI_SERVER_VERSION  0x00000002
#define SI_SERVER_TYPE     0x00000004
#define SI_SERVER_FLAGS    0x00000008
#define SI_NUM_USERS       0x00000010
#define SI_SERVER_NAME     0x00000020
#define SI_HTTP_URL        0x00000040
#define SI_UBC_URL         0x00000080
#define SI_UBC_PARAMS      0x00000100
#define SI_UBC_SKIN_URL    0x00000200
#define SI_SERVER_ID       0x00000400
#define SI_AVATAR          0x00000800

/* extended information keys */
#define SI_EXT_NAME    0x4E414D45 /* 'NAME' username, for authentication */
#define SI_EXT_PASS    0x50415353 /* 'PASS' password, for authentication */
#define SI_EXT_TYPE    0x54595045 /* 'TYPE' client type, for special handling*/
#define SI_EXT_UBC_URL 0x5555524C /* 'UURL' document root of client applet */
/* error response keys */
#define SI_ERR_AUTH       0x41555448 /* 'AUTH' - authentication needed */
#define SI_ERR_UNKN       0x554E4B4E /* 'UNKN' - unknown info requested */
/* information response keys */
#define SI_INF_AURL       0x4155524C /* 'AURL' - default avatar URL */
#define SI_INF_VERS       0x56455253 /* 'VERS' - server version string */
#define SI_INF_TYPE       0x54595045 /* 'TYPE' - server type */
#define SI_INF_FLAG       0x464C4147 /* 'FLAG' - server flags */
#define SI_INF_NUM_USERS  0x4E555352 /* 'NUSR' - number of users */
#define SI_INF_NAME       0x4E414D45 /* 'NAME' - server name */
#define SI_INF_HURL       0x4855524C /* 'HURL' - HTTP (picture) URL */
#define SI_INF_UBC_URL    0x5555524C /* 'UURL' - URL which UBC will launch */
#define SI_INF_UBC_PARAMS 0x55424331 /* 'UBC1' - params to applet */
#define SI_INF_UBC_SKIN_URL 0x55424353 /* 'UBCS' - URL for UBC skin */
#define SI_INF_SERVER_ID  0x50534944 /* 'PSID' - Palace server ID */
#define SI_INF_AVATAR     0x41564154 /* 'AVAT' - Type 1 avatar info */

/*****************************************************************************/

extern Boolean gQuitFlag;

/*****************************************************************************/

#endif /* __MANSION__ */
