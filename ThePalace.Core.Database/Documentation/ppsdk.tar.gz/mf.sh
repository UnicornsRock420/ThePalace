#!/bin/sh

if [ ! -e ${1}.c ]
then
    exit;
fi

dir="${2}"

if [ ! -d $dir ] || [ "$dir" = "" ]
then
    dir=`pwd`
fi

plgn="${3}"

if [ "${plgn}" = "" ]
then
    plgn="${1}.so"
else
    plgn="${1}-${3}.so"
fi

arg="-g -Os ${4} -fmerge-all-constants -fdata-sections -falign-loops -falign-jumps -falign-functions -fstrict-aliasing -fthread-jumps -fcse-skip-blocks -fexpensive-optimizations -fsingle-precision-constant"

rm -rf ${dir}/${plgn}
gcc-3.3 -s -shared $arg ${1}.c -o ${dir}/${plgn}
if [ -e ${dir}/${plgn} ]
then
    chmod 755 ${dir}/${plgn}
    ls --color=always -als $dir/*.so
fi
