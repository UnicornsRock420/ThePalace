/*
 * s-pluginapi.h
 *
 * Declarations for the Palace server plugin API, as seen by the plugin.
 *
 * Copyright 1999 Communities.com. All rights reserved worldwide.
 */

#ifndef __PLUGINAPI__
#define __PLUGINAPI__

#include <ppsdk/s-serverpublic.h>

/**
 * Opaque object identifying a plugin amongst all the plugins currently loaded.
 */
typedef int PluginID;

/**
 * Palace server state struct. The server itself stores all of the things in
 * this struct in globals. Ugly, but that's the way it is.  However, we don't
 * really want to expose the entire set of globals through the plugin API, so
 * we use this struct instead.
 */
typedef struct {
    ServerUserRec *currentUser;
    ServerRoomRec *entrance;
    int nbrRooms;
    ServerRoomRec *roomList;
    int nbrUsers;
    ServerUserRec *userList;
    int maxPeoplePerRoom;
} ServerState;

typedef struct {
    uint32   versionID;          /* Server version number R */
    char     serverName[32];     /* Server name RW */
    char     wizardPassword[32]; /* Wizard password W */
    char     godPassword[32];    /* God password W */
    uint32   permissions;        /* Permission settings RW */
    int      deathPenaltyMinutes;/* Duration that killed users stay dead RW */
    uint16   purgePropDays;      /* Purge props after N days RW */
    uint16   minFloodEvents;     /* Kill flooders after N events RW */
    uint16   maxOccupancy;       /* Total server max occupancy R */
    uint16   roomOccupancy;      /* Per room max occupancy RW */
    char     sysop[64];          /* Name of sysop RW */
    char     url[128];           /* URL to reach server RW */
    char     machineType[128];   /* Machine description RW */
    char     description[256];   /* Palace description RW */
    char     announcement[256];  /* Announcement RW */
    char     ypHost[128];        /* Hostname:port of YP service RW */
    Boolean  autoRegister;       /* TRUE==>autoregister with YP service RW */
    char     picDir[256];        /* Path to server's media RW */
    uint32   serverOptions;      /* Server configuration options RW */
    char     logonMsg[256];      /* Message to user's logging on RW */
    char     mediaServerURL[128];/* HTTP server to get pics from RW */
    char     avatarServerURL[128]; /* HTTP server for Java client avatars RW */
    char     authHost[128];      /* Hostname of authentication server RW */
    uint16   authPort;           /* Port of authentication server RW */
    uint16   authAttempts;       /* Permitted # of failed authorizations RW */
    uint16   poundCheck;         /* Time interval for checking "pounding" RW */

    /* These added in the version 4.4 server */
    uint16   propControl;        /* Minimum user level that can add props RW */
    Boolean  useOtherAvatarServer; /* Tell UBC clients to use custom avs RW */
    Boolean  javaForceWebPage;   /* Make UBC clients use specific URL RW */
    char     javaClientWebPage[128]; /* We page forced to UBC clients RW */
    char     javaAllowedURLs[512]; /* Web pages allowed to frame UBC RW */
    char     UBCUISwitches[128]; /* UBC user interface switches RW */
    char     UBCUISkinURL[128];  /* URL which customizes Java client RW */
} ServerConfiguration;

#define RECEIVE_BUFFER_LENGTH          32000

/**
 * Information about a connection made by a server plugin.
 */
typedef struct pluginConnectionStruct {
    struct pluginConnectionStruct *next;
    struct pluginConnectionStruct *prev;
    AnyType connectionDat;
    Boolean isPalaceConnection;
    Boolean isInUse;
    Boolean isClosed;
    Boolean isOppositeEndian;
    union {
        void (*rawCallback)(ServerState *state,
            struct pluginConnectionStruct *connection, AnyType connectionDat,
            char *data, int length);
        void (*msgCallback)(ServerState *state,
            struct pluginConnectionStruct *connection, AnyType connectionDat,
            ClientMsg *message);
    } callback;
#ifdef unix
    int fd;
    char tcpReceiveBuffer[RECEIVE_BUFFER_LENGTH];
    int tcpReceiveIndex;
#endif
} PluginConnection;

typedef void (*RawCallback)(ServerState *state, PluginConnection *connection,
    AnyType connectionDat, char *data, int length);
typedef void (*MsgCallback)(ServerState *state, PluginConnection *connection,
    AnyType connectionDat, ClientMsg *message);
typedef RawCallback (*RawAcceptor)(ServerState *state,
    PluginConnection *connection, AnyType *connectionDatptr, IPAddress where);
typedef MsgCallback (*MsgAcceptor)(ServerState *state,
    PluginConnection *connection, AnyType *connectionDatptr, IPAddress where);

/**
 * Information about a connection listener for a server plugin.
 */
typedef struct pluginListenerStruct {
    struct pluginListenerStruct *next;
    struct pluginListenerStruct *prev;
    Boolean isListeningForPalaceConnection;
    union {
        RawCallback (*rawAcceptor)(ServerState *state,
            PluginConnection *connection, AnyType *connectionDatptr,
            IPAddress where);
        MsgCallback (*msgAcceptor)(ServerState *state,
            PluginConnection *connection, AnyType *connectionDatptr,
            IPAddress where);
    } acceptor;
#ifdef unix
    int fd;
#endif
} PluginListener;

/* Performance data structures */
#define Prfm_FEStat     0x00656e00  /* 'FeSt' Front end stats */
#define Prfm_MsgTime    0x4d73546d  /* 'MsTm' Message processing time */
#define Prfm_MsgTime2   0x4d735432  /* 'MsT2' Message processing time rev 2 */
#define Prfm_Send       0x53656e64  /* 'Send' Message sent */

typedef struct {
    uint32 eventType;
    uint32 length;
    uint32 procTime;
} Prfm_MsgTiming;

typedef struct {
    uint32 eventType;
    uint32 length;
    uint32 procTime;
    uint32 queTime;
 } Prfm_MsgTiming2;

typedef struct {
    uint32 eventType;
    UserID userID;
    uint32 length;
} Prfm_MsgSend;

typedef struct {
    uint16  feID;
    uint8   down;
    uint16  numUsers;
    uint16  cpuPct;
    uint16  memSize;
    uint16  memPct;
    uint16  ttlcpupct;
} Prfm_FrntEndStat;

typedef struct {
    uint32  DataType;
    union {
        Prfm_MsgSend        Send;
        Prfm_MsgTiming      MessageTime;
        Prfm_MsgTiming2     MessageTime2;
        Prfm_FrntEndStat    FrontEndStats;
    } Data;
} PerformanceData;

#ifndef _WINDLL
/* Functions which a server plugin may implement */
ClientMsg *handleMessage(ServerState *state, AnyType pluginDat, ClientMsg *message);
void handleTimerEvent(ServerState *state, AnyType pluginDat, AnyType timerDat);
AnyType initializeServerPlugin(PluginID pluginID, int argc, char *argv[]);
void noteRoomCreation(ServerState *state, AnyType pluginDat, ServerRoomRec *room);
void noteRoomDeletion(ServerState *state, AnyType pluginDat, ServerRoomRec *room);
void noteUserCreation(ServerState *state, AnyType pluginDat, ServerUserRec *user);
void noteUserDeletion(ServerState *state, AnyType pluginDat, ServerUserRec *user);
void noteUserRoomEntry(ServerState *state, AnyType pluginDat, ServerUserRec *user, ServerRoomRec *room);
void handlePerformanceData(ServerState *state, AnyType pluginDat, PerformanceData *performanceData);
void shutdownServerPlugin(ServerState *state, AnyType pluginDat);
#endif

/* Functions which directly support the server plugin */
SERVER_PLUGIN_API void closeConnection(PluginConnection *connection);
SERVER_PLUGIN_API void deliverMessageDirect(PluginID pluginID, ClientMsg *msg, ServerUserRec *sender);
SERVER_PLUGIN_API void deliverMessageNormal(PluginID pluginID, ClientMsg *msg, ServerUserRec *sender);
SERVER_PLUGIN_API void *getPluginRoomInfo(PluginID pluginID, ServerRoomRec *room);
SERVER_PLUGIN_API void *getPluginUserInfo(PluginID pluginID, ServerUserRec *user);
SERVER_PLUGIN_API void getServerConfiguration(ServerConfiguration *config);
SERVER_PLUGIN_API PluginListener *listenForPalaceConnections(char *host, int port, MsgAcceptor acceptor);
SERVER_PLUGIN_API PluginListener *listenForRawConnections(char *host, int port, RawAcceptor acceptor);
SERVER_PLUGIN_API PluginConnection *openPalaceConnection(char *host, int port, AnyType connectionDat, MsgCallback callback);
SERVER_PLUGIN_API PluginConnection *openRawConnection(char *host, int port, AnyType connectionDat, RawCallback callback);
SERVER_PLUGIN_API void scheduleTimerEvent(PluginID pluginID, AnyType timerDat, int when);
SERVER_PLUGIN_API int sendConnection(PluginConnection *connection, char *data, int length);
SERVER_PLUGIN_API void setPluginRoomInfoSize(PluginID pluginID, int size);
SERVER_PLUGIN_API void setPluginUserInfoSize(PluginID pluginID, int size);
SERVER_PLUGIN_API void setServerConfiguration(ServerConfiguration *config);
SERVER_PLUGIN_API void stopListening(PluginListener *listener);
#ifdef unix
SERVER_PLUGIN_API void registerForSelect(int fd, AnyType dat, void selectCallback(int fd, AnyType dat));
SERVER_PLUGIN_API void unregisterForSelect(int fd);
#endif
SERVER_PLUGIN_API Boolean ActionExists(ServerUserRec *subject, ServerUserRec *target, int action);
SERVER_PLUGIN_API void AddDrawCommand(ServerUserRec *user, DrawRecord *drawCmd);
SERVER_PLUGIN_API void addLoosePropToRoom(ServerUserRec *user, AssetSpec propSpec, Point pos, int avatarType, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API int BanUserByKey(ServerUserRec *whoKilled, char *key, int why, int penaltyMinutes, uint32 siteFlag);
SERVER_PLUGIN_API void BanUserByIP(ServerUserRec *whoKilled, ServerUserRec *user, int why, int penaltyMinutes, uint32 siteFlag);
SERVER_PLUGIN_API void BanIP(ServerUserRec *whoKilled, uint32 ipAddress, int penaltyMinutes, uint32 siteFlag);
SERVER_PLUGIN_API void InsertBanRec(IPBanRec *rec);
SERVER_PLUGIN_API void CommentBanRec(ServerUserRec *user, char *str);
SERVER_PLUGIN_API void ExtendBanRec(ServerUserRec *user, char *str);
SERVER_PLUGIN_API void TrackCheck(ServerUserRec *user);
SERVER_PLUGIN_API void changeUserAvatar(ServerUserRec *user, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN], Boolean broadcast);
SERVER_PLUGIN_API void changeUserAvatarDesc(ServerUserRec *user, int colorNbr, int faceNbr, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN], Boolean broadcast);
SERVER_PLUGIN_API void changeUserAvatarFlags(ServerUserRec *user, uint16 avatarFlags, Boolean broadcast);
SERVER_PLUGIN_API void ChangeUserColor(ServerUserRec *user, int colorNbr);
SERVER_PLUGIN_API void ChangeUserDesc(ServerUserRec *user, int colorNbr, int faceNbr, int nbrProps, AssetSpec *props);
SERVER_PLUGIN_API void ChangeUserFace(ServerUserRec *user, int faceNbr);
SERVER_PLUGIN_API void ChangeUserName(ServerUserRec *user, StringPtr name);
SERVER_PLUGIN_API void ChangeUserProp(ServerUserRec *user, int nbrProps, AssetSpec *props);
SERVER_PLUGIN_API void ChangeUserRoom(ServerUserRec *user, ServerRoomRec *newRoom, Boolean forcedEntry);
SERVER_PLUGIN_API void CheckForProp(ServerUserRec *user, MsgFanout *provider, AssetID propID, uint32 crc);
SERVER_PLUGIN_API void computeUserIDNumber(ServerUserRec *user, char *result);
SERVER_PLUGIN_API ServerUserRec *createPhantomUser();
SERVER_PLUGIN_API void DecryptCString(unsigned char *inStr, char *outStr, int len, Boolean doubleByte);
SERVER_PLUGIN_API void DecryptString(StringPtr inStr, StringPtr outStr);
SERVER_PLUGIN_API void DeleteLooseProp(ServerUserRec *user, sint32 propNum);
SERVER_PLUGIN_API void DeleteRoom(ServerRoomRec *room);
SERVER_PLUGIN_API void DeleteSpot(ServerUserRec *user, HotspotID spotID);
SERVER_PLUGIN_API double DoubleRandom();
SERVER_PLUGIN_API void DoUnBan(ServerUserRec *user, char *str, Boolean trackerFlag);
SERVER_PLUGIN_API RoomID DuplicateRoom(ServerUserRec *user, ServerRoomRec *room);
SERVER_PLUGIN_API void EncryptCString(char *inStr, unsigned char *outStr, int len);
SERVER_PLUGIN_API void EncryptString(StringPtr inStr, StringPtr outStr);
SERVER_PLUGIN_API void FormattedLogMessage(ServerUserRec *user, char *action, char *str, ...);
SERVER_PLUGIN_API IPBanRec *GetIPBanRecByIP(unsigned int ipAddress, Boolean trackerFlag);
SERVER_PLUGIN_API IPBanRec *GetIPBanRecByCounter(unsigned int counter, Boolean trackerFlag);
SERVER_PLUGIN_API IPBanRec *GetIPBanRecByPuidKey(unsigned int counter, Boolean trackerFlag);
SERVER_PLUGIN_API Hotspot *GetHotspot(ServerRoomRec *room, HotspotID id);
SERVER_PLUGIN_API ServerRoomRec *GetRoom(RoomID id);
SERVER_PLUGIN_API ServerUserRec *GetServerUser(UserID id);
SERVER_PLUGIN_API ServerUserRec *GetServerUserByCounter(ClientID ctr);
SERVER_PLUGIN_API ServerUserRec *GetServerUserByKey(char *key);
SERVER_PLUGIN_API ServerUserRec *GetServerUserByName(char *name);
SERVER_PLUGIN_API void GodGlobalMessage(char *fmt, ...);
SERVER_PLUGIN_API void GodMessage(ServerUserRec *user, char *fmt, ...);
SERVER_PLUGIN_API void GlobalMessage(char *fmt, ...);
SERVER_PLUGIN_API Boolean IllegalText(ServerUserRec *user, char *buffer, Boolean encrypted);
SERVER_PLUGIN_API void LockDoor(ServerUserRec *user, ServerRoomRec *room, HotspotID doorID, Boolean lockFlag);
SERVER_PLUGIN_API void LogoffUser(UserID userID, int why);
SERVER_PLUGIN_API sint32 LongRandom();
SERVER_PLUGIN_API ServerRoomRec *MakeNewRoom(ServerUserRec *user, Boolean memberFlag, char *name);
SERVER_PLUGIN_API void MakeNewSpot(ServerUserRec *user);
SERVER_PLUGIN_API void MoveLooseProp(ServerUserRec *user, sint32 propNum, Point pos);
SERVER_PLUGIN_API sint16 MyRandom(sint16 max);
SERVER_PLUGIN_API void PerformER(ServerUserRec *user);
SERVER_PLUGIN_API void PerformPage(ServerUserRec *user, char *msg);
SERVER_PLUGIN_API void PerformResPage(ServerUserRec *user, char *msg);
SERVER_PLUGIN_API void PostUserEvent(ServerUserRec *user, uint32 eventType, uint32 refNum, void *msg, uint32 length);
SERVER_PLUGIN_API void ProcessFileSend(ServerUserRec *user, StringPtr filename);
SERVER_PLUGIN_API void PurgeBanList(ServerUserRec *user);
SERVER_PLUGIN_API void RecordEventToChatLog(ServerUserRec *fromUser, ServerUserRec *toUser, char *type, char *str);
SERVER_PLUGIN_API void RoomMessage(ServerRoomRec *room, char *fmt, ...);
SERVER_PLUGIN_API void ScheduleUserKill(ServerUserRec *user, int why, char *verboseWhyMsg, int deathPenalty);
SERVER_PLUGIN_API void sendMsg(MsgFanout *to, uint32 msgType, sint32 refNum, void *msg, uint32 length);
SERVER_PLUGIN_API void sendMsgAltLogonReply(MsgFanout *to, ServerUserRec *user, AuxRegistrationRec *regRec);
SERVER_PLUGIN_API void sendMsgAssetQuery(MsgFanout *to, AssetType type, AssetID id, uint32 crc);
SERVER_PLUGIN_API void sendMsgAssetRegi(MsgFanout *to, AssetType type, AssetID id, uint32 crc, StringPtr assetName, sint32 size, char *data);
SERVER_PLUGIN_API void sendMsgAssetSend(MsgFanout *to, AssetType type, AssetID id, uint32 crc, StringPtr assetName, sint32 size, char *data);
SERVER_PLUGIN_API void sendMsgAuthenticate(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgAuthResponse(MsgFanout *to, StringPtr authString);
SERVER_PLUGIN_API void sendMsgAvatarFlags(MsgFanout *to, ServerUserRec *user, uint16 avatarFlags);
SERVER_PLUGIN_API void sendMsgAvatarFlagsRequest(MsgFanout *to, uint16 avatarFlags);
SERVER_PLUGIN_API void sendMsgAvatarQuery(MsgFanout *to, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API void sendMsgAvatarSendData(MsgFanout *to, uint8 hash[AVATAR_HASH_LEN], uint32 dataSize, uint8 *data);
SERVER_PLUGIN_API void sendMsgAvatarSendURL(MsgFanout *to, uint8 hash[AVATAR_HASH_LEN], char *url);
SERVER_PLUGIN_API void sendMsgBadAuth(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgBlowThru(MsgFanout *to, sint32 refCon, char *msg, uint32 length);
SERVER_PLUGIN_API void sendMsgDisplayURL(MsgFanout *to, int pane, char *url);
SERVER_PLUGIN_API void sendMsgDoorLock(MsgFanout *to, RoomID roomID, HotspotID doorID);
SERVER_PLUGIN_API void sendMsgDoorUnlock(MsgFanout *to, RoomID roomID, HotspotID doorID);
SERVER_PLUGIN_API void sendMsgDraw(MsgFanout *to, DrawRecord *drawCmd);
SERVER_PLUGIN_API void sendMsgExtendedInfo(MsgFanout *to, ServerUserRec *user, ExtendedInfo *info, uint32 length);
SERVER_PLUGIN_API void sendMsgExtendedInfoRequest(MsgFanout *to, uint32 flags, ExtendedInfo *info, uint32 length);
SERVER_PLUGIN_API void sendMsgFileNotFnd(MsgFanout *to, StringPtr filename);
SERVER_PLUGIN_API void sendMsgFileQuery(MsgFanout *to, StringPtr filename);
SERVER_PLUGIN_API void sendMsgFileSend(MsgFanout *to, FileBlockHeader *sendBlock, uint32 size);
SERVER_PLUGIN_API void sendMsgGetOrSetPrefsRequest(MsgFanout *to, uint8 *passwordHash, uint8 *passwordSalt, uint32 numPrefs, char *prefs);
SERVER_PLUGIN_API void sendMsgGetOrSetPrefsReply(MsgFanout *to, uint32 numPrefs, uint32 numErrors, char *prefs, char *errors);
SERVER_PLUGIN_API void sendMsgGetUserIdentityRequest(MsgFanout *to, UserID targetID);
SERVER_PLUGIN_API void sendMsgGetUserIdentityResponse(MsgFanout *to, ServerUserRec *who, char *identity);
SERVER_PLUGIN_API void sendMsgGMsg(MsgFanout *to, UserID who, char *speech);
SERVER_PLUGIN_API void sendMsgHTTPServer(MsgFanout *to, char *url);
SERVER_PLUGIN_API void sendMsgKillUser(MsgFanout *to, UserID targetID);
SERVER_PLUGIN_API void sendMsgListOfAllRooms(MsgFanout *to, int nbrRooms, RoomListRec *roomList, uint32 size);
SERVER_PLUGIN_API void sendMsgListOfAllRoomsRequest(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgListOfAllUsers(MsgFanout *to, int nbrUsers, UserListRec *userList, uint32 size);
SERVER_PLUGIN_API void sendMsgListOfAllUsersRequest(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgLogoff(MsgFanout *to, ServerUserRec *user, sint32 nbrUsers);
SERVER_PLUGIN_API void sendMsgLogoffRequest(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgLogon(MsgFanout *to, UserID userid, AuxRegistrationRec *regrec);
SERVER_PLUGIN_API void sendMsgNavError(MsgFanout *to, int errorNumber);
SERVER_PLUGIN_API void sendMsgPictMove(MsgFanout *to, RoomID roomID, HotspotID spotID, Point pos);
SERVER_PLUGIN_API void sendMsgPing(MsgFanout *to, sint32 refCon);
SERVER_PLUGIN_API void sendMsgPong(MsgFanout *to, sint32 refCon);
SERVER_PLUGIN_API void sendMsgPropDel(MsgFanout *to, sint32 propNum);
SERVER_PLUGIN_API void sendMsgPropMove(MsgFanout *to, sint32 propNum, Point pos);
SERVER_PLUGIN_API void sendMsgPropNew(MsgFanout *to, AssetSpec propSpec, Point propLoc);
SERVER_PLUGIN_API void sendMsgPropNewExtended(MsgFanout *to, AssetSpec propSpec, Point propLoc, sint16 avatarType, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API void sendMsgRMsg(MsgFanout *to, UserID who, char *speech);
SERVER_PLUGIN_API void sendMsgRoomDesc(MsgFanout *to, ServerRoomRec *room);
SERVER_PLUGIN_API void sendMsgRoomDescEnd(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgRoomGoto(MsgFanout *to, RoomID dest);
SERVER_PLUGIN_API void sendMsgRoomNew(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgRoomSetDesc(MsgFanout *to, ServerRoomRec *room);
SERVER_PLUGIN_API void sendMsgRoomSetDescRequest(MsgFanout *to, RoomRec *room, char *varBuf);
SERVER_PLUGIN_API void sendMsgServerDown(MsgFanout *to, int why, char *whyMessage);
SERVER_PLUGIN_API void sendMsgServerInfo(MsgFanout *to, ServerUserRec *user, ServerInfo *info, uint32 length);
SERVER_PLUGIN_API void sendMsgSMsg(MsgFanout *to, UserID who, char *speech);
SERVER_PLUGIN_API void sendMsgSpotDel(MsgFanout *to, HotspotID spotID);
SERVER_PLUGIN_API void sendMsgSpotMove(MsgFanout *to, RoomID roomID, HotspotID spotID, Point pos);
SERVER_PLUGIN_API void sendMsgSpotNew(MsgFanout *to);
SERVER_PLUGIN_API void sendMsgSpotState(MsgFanout *to, RoomID roomID, HotspotID spotID, sint16 state);
SERVER_PLUGIN_API void sendMsgSuperuser(MsgFanout *to, StringPtr password);
SERVER_PLUGIN_API void sendMsgTalk(MsgFanout *to, UserID who, char *speech);
SERVER_PLUGIN_API void sendMsgTIYID(MsgFanout *to, ServerUserRec *user);
SERVER_PLUGIN_API void sendMsgUserColor(MsgFanout *to, ServerUserRec *user, sint16 colorNbr);
SERVER_PLUGIN_API void sendMsgUserColorRequest(MsgFanout *to, sint16 colorNbr);
SERVER_PLUGIN_API void sendMsgUserDesc(MsgFanout *to, ServerUserRec *user, sint16 faceNbr, sint16 colorNbr, int nbrProps, AssetSpec *props);
SERVER_PLUGIN_API void sendMsgUserDescAvatar(MsgFanout *to, ServerUserRec *user, sint16 faceNbr, sint16 colorNbr, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API void sendMsgUserDescRequest(MsgFanout *to, sint16 faceNbr, sint16 colorNbr, int nbrProps, AssetSpec *props);
SERVER_PLUGIN_API void sendMsgUserDescAvatarRequest(MsgFanout *to, sint16 faceNbr, sint16 colorNbr, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API void sendMsgUserExit(MsgFanout *to, ServerUserRec *user);
SERVER_PLUGIN_API void sendMsgUserFace(MsgFanout *to, ServerUserRec *user, sint16 faceNbr);
SERVER_PLUGIN_API void sendMsgUserFaceRequest(MsgFanout *to, sint16 faceNbr);
SERVER_PLUGIN_API void sendMsgUserList(MsgFanout *to, int nbrUsers, UserRec *userList);
SERVER_PLUGIN_API void sendMsgUserLog(MsgFanout *to, ServerUserRec *user, sint32 nbrUsers);
SERVER_PLUGIN_API void sendMsgUserMove(MsgFanout *to, ServerUserRec *user, Point pos);
SERVER_PLUGIN_API void sendMsgUserMoveRequest(MsgFanout *to, Point pos);
SERVER_PLUGIN_API void sendMsgUserName(MsgFanout *to, ServerUserRec *user, StringPtr name);
SERVER_PLUGIN_API void sendMsgUserNameRequest(MsgFanout *to, StringPtr name);
SERVER_PLUGIN_API void sendMsgUserNew(MsgFanout *to, ServerUserRec *user);
SERVER_PLUGIN_API void sendMsgUserProp(MsgFanout *to, ServerUserRec *user, int nbrProps, AssetSpec *props);
SERVER_PLUGIN_API void sendMsgUserPropAvatar(MsgFanout *to, ServerUserRec *user, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API void sendMsgUserPropRequest(MsgFanout *to, int nbrProps, AssetSpec *props);
SERVER_PLUGIN_API void sendMsgUserPropAvatarRequest(MsgFanout *to, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
SERVER_PLUGIN_API void sendMsgUserStatus(MsgFanout *to, ServerUserRec *user, uint16 flags, char *godhash);
SERVER_PLUGIN_API void sendMsgVersion(MsgFanout *to, sint32 versionNumber);
SERVER_PLUGIN_API void sendMsgWhisper(MsgFanout *to, UserID who, char *speech);
SERVER_PLUGIN_API void sendMsgWhisperRequest(MsgFanout *to, UserID who, UserID target, char *speech);
SERVER_PLUGIN_API void sendMsgXTalk(MsgFanout *to, UserID who, char *speech, uint32 length);
SERVER_PLUGIN_API void sendMsgXWhisper(MsgFanout *to, UserID who, char *speech, uint32 length);
SERVER_PLUGIN_API void sendMsgXWhisperRequest(MsgFanout *to, UserID who, UserID target, char *speech, uint32 length);
SERVER_PLUGIN_API void SetRoomInfo(ServerUserRec *user, RoomRec *room);
SERVER_PLUGIN_API void SetUserAction(ServerUserRec *user, char *arg, int action, Boolean setFlag);
SERVER_PLUGIN_API MsgFanout *toConnection(PluginConnection *connection);
SERVER_PLUGIN_API MsgFanout *toGlobal(void);
SERVER_PLUGIN_API MsgFanout *toNeighbor(ServerUserRec *who);
SERVER_PLUGIN_API MsgFanout *toRoom(ServerRoomRec *where);
SERVER_PLUGIN_API MsgFanout *toUserRoom(ServerUserRec *who);
SERVER_PLUGIN_API MsgFanout *toUser(ServerUserRec *who);
SERVER_PLUGIN_API void UpdatePictureLocation(ServerUserRec *user, ServerRoomRec *room, HotspotID spotID, Point pos);
SERVER_PLUGIN_API void UpdateSpotLocation(ServerUserRec *user, ServerRoomRec *room, HotspotID spotID, Point pos);
SERVER_PLUGIN_API void UpdateSpotState(ServerUserRec *user, ServerRoomRec *room, HotspotID spotID, sint16 state);
SERVER_PLUGIN_API void UpdateUserPosition(ServerUserRec *user, Point newpos, Boolean force);
SERVER_PLUGIN_API void UserAssetQuery(ServerUserRec *user, void *assetMsg);
SERVER_PLUGIN_API void UserMessage(ServerUserRec *user, char *fmt, ...);
SERVER_PLUGIN_API void UserPrivateMessage(ServerUserRec *user, char *fmt, ...);
SERVER_PLUGIN_API int UserRank(ServerUserRec *user);
SERVER_PLUGIN_API void WizGlobalMessage(char *fmt, ...);
SERVER_PLUGIN_API void WizNeighborMessage(ServerUserRec *user, char *fmt, ...);
SERVER_PLUGIN_API void WizRoomMessage(ServerRoomRec *room, char *fmt, ...);
SERVER_PLUGIN_API uint32 ComputeLicenseCRC(uint32 ctr);
SERVER_PLUGIN_API sint32 countUsersInRoomRange(RoomID low, RoomID high);
SERVER_PLUGIN_API char *CvtToCString(StringPtr str);
SERVER_PLUGIN_API Boolean LittleEndian(void);
SERVER_PLUGIN_API void LogError(int error, char *str, ...);
SERVER_PLUGIN_API void PerformRespond(ServerUserRec *user, char *msg);
SERVER_PLUGIN_API Boolean pluginRegisterCommand(char *pattern, char *helpSyntax, int minArgs, int maxArgs, CommandResult (*commandFunc)(ServerUserRec *user, int argc, char *argv[]), int defaultRank, char *helpText);
SERVER_PLUGIN_API void SeedToWizKey(ServerUserRec *user, char *seedStr, Boolean regHash);
SERVER_PLUGIN_API void strcatSafe(char *buf, char *str, int len);
SERVER_PLUGIN_API char *strncpySafe(char *dest, char *src, int len);
SERVER_PLUGIN_API Boolean testArgNum(char *arg, int *numptr);
SERVER_PLUGIN_API Boolean testArgOff(char *arg);
SERVER_PLUGIN_API Boolean testArgOn(char *arg);
SERVER_PLUGIN_API uint32 SwapLong(uint32 *n);

#ifndef WIN32
#if !TARGET_OS_MAC
void CtoPstr(char *str);
void DisposePtr(void *ptr);
char *NewPtr(uint32 size);
char *NewPtrClear(uint32 size);
void PtoCstr(StringPtr str);
#endif /* !TARGET_OS_MAC */
#endif /* WIN32 */

#ifdef _WINDOWS
#include "stdarg.h"

typedef struct
{
    void (*deliverMessageDirect)(PluginID pluginID, ClientMsg *msg,
        ServerUserRec *sender);
    void (*deliverMessageNormal)(PluginID pluginID, ClientMsg *msg,
        ServerUserRec *sender);
    void* (*getPluginRoomInfo)(PluginID pluginID, ServerRoomRec *room);
    void* (*getPluginUserInfo)(PluginID pluginID, ServerUserRec *user);
    void (*getServerConfiguration)(ServerConfiguration *config);
    void (*scheduleTimerEvent)(PluginID pluginID, AnyType timerDat, int when);
    void (*setPluginRoomInfoSize)(PluginID pluginID, int size);
    void (*setPluginUserInfoSize)(PluginID pluginID, int size);
    void (*setServerConfiguration)(ServerConfiguration *config);
    Boolean (*ActionExists)(ServerUserRec *subject, ServerUserRec *target,
        int action);
    void (*AddDrawCommand)(ServerUserRec *user, DrawRecord *drawCmd);
    void (*addLoosePropToRoom)(ServerUserRec *user, AssetSpec propSpec,
        Point pos, int avatarType, uint16 avatarFlags,
        uint8 hash[AVATAR_HASH_LEN]);
    int (*BanUserByKey)(ServerUserRec *whoKilled, char *key, int why,
        int penaltyMinutes, uint32 siteFlag);
    void (*ChangeUserColor)(ServerUserRec *user, int colorNbr);
    void (*ChangeUserDesc)(ServerUserRec *user, int colorNbr, int faceNbr,
        int nbrProps, AssetSpec *props);
    void (*ChangeUserFace)(ServerUserRec *user, int faceNbr);
    void (*ChangeUserName)(ServerUserRec *user, StringPtr name);
    void (*ChangeUserProp)(ServerUserRec *user, int nbrProps,
        AssetSpec *props);
    void (*ChangeUserRoom)(ServerUserRec *user, ServerRoomRec *newRoom,
        Boolean forcedEntry);
    void (*DecryptCString)(unsigned char *inStr, char *outStr, int len,
        Boolean doubleByte);
    void (*DecryptString)(StringPtr inStr, StringPtr outStr);
    void (*DeleteLooseProp)(ServerUserRec *user, sint32 propNum);
    void (*DeleteRoom)(ServerRoomRec *room);
    void (*DeleteSpot)(ServerUserRec *user, HotspotID spotID);
    double (*DoubleRandom)();
    void (*DoUnBan)(ServerUserRec *user, char *str, Boolean trackerFlag);
    RoomID (*DuplicateRoom)(ServerUserRec *user, ServerRoomRec *room);
    void (*EncryptCString)(char *inStr, unsigned char *outStr, int len);
    void (*EncryptString)(StringPtr inStr, StringPtr outStr);
    void (*FormattedLogMessageVA)(ServerUserRec *user, char *action, char *str,
        va_list varArg);
    Hotspot* (*GetHotspot)(ServerRoomRec *room, HotspotID id);
    ServerRoomRec* (*GetRoom)(RoomID id);
    ServerUserRec* (*GetServerUser)(UserID id);
    ServerUserRec* (*GetServerUserByCounter)(ClientID ctr);
    ServerUserRec* (*GetServerUserByKey)(char *key);
    ServerUserRec* (*GetServerUserByName)(char *name);
    void (*GodGlobalMessageVA)(char *fmt, va_list varArg);
    void (*GodMessageVA)(ServerUserRec *user, char *fmt, va_list varArg);
    void (*GlobalMessageVA)(char *fmt, va_list varArg);
    Boolean (*IllegalText)(ServerUserRec *user, char *buffer,
        Boolean encrypted);
    void (*LockDoor)(ServerUserRec *user, ServerRoomRec *room,
        HotspotID doorID, Boolean lockFlag);
    void (*LogoffUser)(UserID userID, int why);
    sint32 (*LongRandom)();
    ServerRoomRec* (*MakeNewRoom)(ServerUserRec *user, Boolean memberFlag,
        char *name);
    void (*MakeNewSpot)(ServerUserRec *user);
    void (*MoveLooseProp)(ServerUserRec *user, sint32 propNum, Point pos);
    sint16 (*MyRandom)(sint16 max);
    void (*PerformER)(ServerUserRec *user);
    void (*PerformPage)(ServerUserRec *user, char *msg);
    void (*PerformResPage)(ServerUserRec *user, char *msg);
    void (*PurgeBanList)(ServerUserRec *user);
    void (*RecordEventToChatLog)(ServerUserRec *fromUser,
        ServerUserRec *toUser, char *type, char *str);
    void (*RoomMessageVA)(ServerRoomRec *room, char *fmt, va_list varArg);
    void (*ScheduleUserKill)(ServerUserRec *user, int why, char *verboseWhyMsg,
        int deathPenalty);
    void (*sendMsg)(MsgFanout *to, uint32 msgType, sint32 refNum, void *msg,
        uint32 length);
    void (*sendMsgAltLogonReply)(MsgFanout *to, ServerUserRec *user,
        AuxRegistrationRec *regRec);
    void (*sendMsgAssetQuery)(MsgFanout *to, AssetType type, AssetID id,
        uint32 crc);
    void (*sendMsgAssetSend)(MsgFanout *to, AssetType type, AssetID id,
        uint32 crc, StringPtr assetName, sint32 size, char *data);
    void (*sendMsgAuthenticate)(MsgFanout *to);
    void (*sendMsgBlowThru)(MsgFanout *to, sint32 refCon, char *msg,
        uint32 length);
    void (*sendMsgDisplayURL)(MsgFanout *to, int pane, char *url);
    void (*sendMsgDoorLock)(MsgFanout *to, RoomID roomID, HotspotID doorID);
    void (*sendMsgDoorUnlock)(MsgFanout *to, RoomID roomID, HotspotID doorID);
    void (*sendMsgDraw)(MsgFanout *to, DrawRecord *drawCmd);
    void (*sendMsgExtendedInfo)(MsgFanout *to, ServerUserRec *user,
        ExtendedInfo *info, uint32 length);
    void (*sendMsgFileNotFnd)(MsgFanout *to, StringPtr filename);
    void (*sendMsgFileSend)(MsgFanout *to, FileBlockHeader *sendBlock,
        uint32 size);
    void (*sendMsgHTTPServer)(MsgFanout *to, char *url);
    void (*sendMsgListOfAllRooms)(MsgFanout *to, int nbrRooms,
        RoomListRec *roomList, uint32 size);
    void (*sendMsgListOfAllRoomsRequest)(MsgFanout *to);
    void (*sendMsgListOfAllUsers)(MsgFanout *to, int nbrUsers,
        UserListRec *userList, uint32 size);
    void (*sendMsgListOfAllUsersRequest)(MsgFanout *to);
    void (*sendMsgLogoff)(MsgFanout *to, ServerUserRec *user, sint32 nbrUsers);
    void (*sendMsgNavError)(MsgFanout *to, int errorNumber);
    void (*sendMsgPictMove)(MsgFanout *to, RoomID roomID, HotspotID spotID,
        Point pos);
    void (*sendMsgPing)(MsgFanout *to, sint32 refCon);
    void (*sendMsgPong)(MsgFanout *to, sint32 refCon);
    void (*sendMsgPropDel)(MsgFanout *to, sint32 propNum);
    void (*sendMsgPropMove)(MsgFanout *to, sint32 propNum, Point pos);
    void (*sendMsgPropNew)(MsgFanout *to, AssetSpec propSpec, Point propLoc);
    void (*sendMsgRoomDesc)(MsgFanout *to, ServerRoomRec *room);
    void (*sendMsgRoomDescEnd)(MsgFanout *to);
    void (*sendMsgRoomSetDesc)(MsgFanout *to, ServerRoomRec *room);
    void (*sendMsgServerDown)(MsgFanout *to, int why, char *whyMessage);
    void (*sendMsgServerInfo)(MsgFanout *to, ServerUserRec *user,
        ServerInfo *info, uint32 length);
    void (*sendMsgSpotMove)(MsgFanout *to, RoomID roomID, HotspotID spotID,
        Point pos);
    void (*sendMsgSpotState)(MsgFanout *to, RoomID roomID, HotspotID spotID,
        sint16 state);
    void (*sendMsgTalk)(MsgFanout *to, UserID who, char *speech);
    void (*sendMsgTIYID)(MsgFanout *to, ServerUserRec *user);
    void (*sendMsgUserColor)(MsgFanout *to, ServerUserRec *user,
        sint16 colorNbr);
    void (*sendMsgUserDesc)(MsgFanout *to, ServerUserRec *user, sint16 faceNbr,
        sint16 colorNbr, int nbrProps, AssetSpec *props);
    void (*sendMsgUserExit)(MsgFanout *to, ServerUserRec *user);
    void (*sendMsgUserFace)(MsgFanout *to, ServerUserRec *user,
        sint16 faceNbr);
    void (*sendMsgUserList)(MsgFanout *to, int nbrUsers, UserRec *userList);
    void (*sendMsgUserLog)(MsgFanout *to, ServerUserRec *user,
        sint32 nbrUsers);
    void (*sendMsgUserMove)(MsgFanout *to, ServerUserRec *user, Point pos);
    void (*sendMsgUserName)(MsgFanout *to, ServerUserRec *user,
        StringPtr name);
    void (*sendMsgUserNew)(MsgFanout *to, ServerUserRec *user);
    void (*sendMsgUserProp)(MsgFanout *to, ServerUserRec *user, int nbrProps,
        AssetSpec *props);
    void (*sendMsgUserStatus)(MsgFanout *to, ServerUserRec *user,
        uint16 flags, char *godhash);
    void (*sendMsgVersion)(MsgFanout *to, sint32 versionNumber);
    void (*sendMsgWhisper)(MsgFanout *to, UserID who, char *speech);
    void (*sendMsgXTalk)(MsgFanout *to, UserID who, char *speech,
        uint32 length);
    void (*sendMsgXWhisper)(MsgFanout *to, UserID who, char *speech,
        uint32 length);
    void (*SetRoomInfo)(ServerUserRec *user, RoomRec *room);
    void (*SetUserAction)(ServerUserRec *user, char *arg, int action,
        Boolean setFlag);
    MsgFanout* (*toGlobal)(void);
    MsgFanout* (*toNeighbor)(ServerUserRec *who);
    MsgFanout* (*toRoom)(ServerRoomRec *where);
    MsgFanout* (*toUserRoom)(ServerUserRec *who);
    MsgFanout* (*toUser)(ServerUserRec *who);
    void (*UpdatePictureLocation)(ServerUserRec *user, ServerRoomRec *room,
        HotspotID spotID, Point pos);
    void (*UpdateSpotLocation)(ServerUserRec *user, ServerRoomRec *room,
        HotspotID spotID, Point pos);
    void (*UpdateSpotState)(ServerUserRec *user, ServerRoomRec *room,
        HotspotID spotID, sint16 state);
    void (*UpdateUserPosition)(ServerUserRec *user, Point newpos,
        Boolean force);
    void (*UserMessageVA)(ServerUserRec *user, char *fmt, va_list varArg);
    void (*UserPrivateMessageVA)(ServerUserRec *user, char *fmt,
        va_list varArg);
    int (*UserRank)(ServerUserRec *user);
    void (*WizGlobalMessageVA)(char *fmt, va_list varArg);
    void (*WizNeighborMessageVA)(ServerUserRec *user, char *fmt,
        va_list varArg);
    void (*WizRoomMessageVA)(ServerRoomRec *room, char *fmt, va_list varArg);
    uint32 (*ComputeLicenseCRC)(uint32 ctr);
    void (*closeConnection)(PluginConnection *connection);
    PluginConnection *(*openPalaceConnection)(char *host, int port,
        AnyType connectionDat, MsgCallback callback);
    PluginConnection *(*openRawConnection)(char *host, int port,
        AnyType connectionDat, RawCallback callback);
    int (*sendConnection)(PluginConnection *connection, char *data,
        int length);
    MsgFanout *(*toConnection)(PluginConnection *connection);
    ServerUserRec *(*createPhantomUser)();
    void (*sendMsgBadAuth)(MsgFanout *to);
    void (*sendMsgGetOrSetPrefsReply)(MsgFanout *to, uint32 numPrefs,
        uint32 numErrors, char *prefs, char *errors);
    void (*sendMsgGetUserIdentityResponse)(MsgFanout *to, ServerUserRec *who,
        char *identity);
    void (*CheckForProp)(ServerUserRec *user, MsgFanout *provider,
        AssetID propID, uint32 crc);
    PluginListener *(*listenForPalaceConnections)(char *host, int port,
        MsgAcceptor acceptor);
    PluginListener *(*listenForRawConnections)(char *host, int port,
        RawAcceptor acceptor);
    void (*stopListening)(PluginListener *listener);
    Boolean (*LittleEndian)(void);
    uint32 (*SwapLong)(uint32 *n);
    void (*LogError)(int error, char *str, ...);
    char* (*CvtToCString)(StringPtr str);
    sint32 (*countUsersInRoomRange)(RoomID low, RoomID high);

    void (*changeUserAvatar)(ServerUserRec *user, uint16 avatarFlags,
        uint8 hash[AVATAR_HASH_LEN], Boolean broadcast);
    void (*changeUserAvatarDesc)(ServerUserRec *user, int colorNbr,
        int faceNbr, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN],
        Boolean broadcast);
    void (*changeUserAvatarFlags)(ServerUserRec *user, uint16 avatarFlags,
        Boolean broadcast);
    void (*computeUserIDNumber)(ServerUserRec *user, char *result);
    void (*PerformRespond)(ServerUserRec *user, char *msg);
    Boolean (*pluginRegisterCommand)(char *pattern, char *helpSyntax,
        int minArgs, int maxArgs,
        CommandResult (*commandFunc)(ServerUserRec *user, int argc,
            char *argv[]),
       int defaultRank, char *helpText);
    void (*strcatSafe)(char *buf, char *str, int len);
    char *(*strncpySafe)(char *dest, char *src, int len);
    void (*sendMsgAvatarFlags)(MsgFanout *to, ServerUserRec *user,
        uint16 avatarFlags);
    void (*sendMsgAvatarFlagsRequest)(MsgFanout *to, uint16 avatarFlags);
    void (*sendMsgAvatarQuery)(MsgFanout *to, uint8 hash[AVATAR_HASH_LEN]);
    void (*sendMsgAvatarSendData)(MsgFanout *to, uint8 hash[AVATAR_HASH_LEN],
        uint32 dataSize, uint8 *data);
    void (*sendMsgAvatarSendURL)(MsgFanout *to, uint8 hash[AVATAR_HASH_LEN],
        char *url);
    void (*sendMsgAssetRegi)(MsgFanout *to, AssetType type, AssetID id,
        uint32 crc, StringPtr assetName, sint32 size, char *data);
    void (*sendMsgAuthResponse)(MsgFanout *to, StringPtr authString);
    void (*sendMsgExtendedInfoRequest)(MsgFanout *to, uint32 flags,
        ExtendedInfo *info, uint32 length);
    void (*sendMsgFileQuery)(MsgFanout *to, StringPtr filename);
    void (*sendMsgGetOrSetPrefsRequest)(MsgFanout *to, uint8 *passwordHash,
        uint8 *passwordSalt, uint32 numPrefs, char *prefs);
    void (*sendMsgGetUserIdentityRequest)(MsgFanout *to, UserID targetID);
    void (*sendMsgGMsg)(MsgFanout *to, UserID who, char *speech);
    void (*sendMsgKillUser)(MsgFanout *to, UserID targetID);
    void (*sendMsgLogoffRequest)(MsgFanout *to);
    void (*sendMsgLogon)(MsgFanout *to, UserID userid,
        AuxRegistrationRec *regrec);
    void (*sendMsgPropNewExtended)(MsgFanout *to, AssetSpec propSpec,
       Point propLoc, sint16 avatarType, uint16 avatarFlags,
       uint8 hash[AVATAR_HASH_LEN]);
    void (*sendMsgRMsg)(MsgFanout *to, UserID who, char *speech);
    void (*sendMsgRoomGoto)(MsgFanout *to, RoomID dest);
    void (*sendMsgRoomNew)(MsgFanout *to);
    void (*sendMsgRoomSetDescRequest)(MsgFanout *to, RoomRec *room,
        char *varBuf);
    void (*sendMsgSMsg)(MsgFanout *to, UserID who, char *speech);
    void (*sendMsgSpotDel)(MsgFanout *to, HotspotID spotID);
    void (*sendMsgSpotNew)(MsgFanout *to);
    void (*sendMsgSuperuser)(MsgFanout *to, StringPtr password);
    void (*sendMsgUserColorRequest)(MsgFanout *to, sint16 colorNbr);
    void (*sendMsgUserDescAvatar)(MsgFanout *to, ServerUserRec *user,
        sint16 faceNbr, sint16 colorNbr, uint16 avatarFlags,
        uint8 hash[AVATAR_HASH_LEN]);
    void (*sendMsgUserDescRequest)(MsgFanout *to, sint16 faceNbr,
        sint16 colorNbr, int nbrProps, AssetSpec *props);
    void (*sendMsgUserDescAvatarRequest)(MsgFanout *to, sint16 faceNbr,
        sint16 colorNbr, uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
    void (*sendMsgUserFaceRequest)(MsgFanout *to, sint16 faceNbr);
    void (*sendMsgUserMoveRequest)(MsgFanout *to, Point pos);
    void (*sendMsgUserNameRequest)(MsgFanout *to, StringPtr name);
    void (*sendMsgUserPropAvatar)(MsgFanout *to, ServerUserRec *user,
        uint16 avatarFlags, uint8 hash[AVATAR_HASH_LEN]);
    void (*sendMsgUserPropRequest)(MsgFanout *to, int nbrProps,
        AssetSpec *props);
    void (*sendMsgUserPropAvatarRequest)(MsgFanout *to, uint16 avatarFlags,
        uint8 hash[AVATAR_HASH_LEN]);
    void (*sendMsgWhisperRequest)(MsgFanout *to, UserID who,
        UserID target, char *speech);
    void (*sendMsgXWhisperRequest)(MsgFanout *to, UserID who,
        UserID target, char *speech, uint32 length);
    Boolean (*testArgNum)(char *arg, int *numptr);
    Boolean (*testArgOff)(char *arg);
    Boolean (*testArgOn)(char *arg);

} HostEntryPoints;

#endif /* _WINDOWS */

#endif /* __PLUGINAPI__ */
