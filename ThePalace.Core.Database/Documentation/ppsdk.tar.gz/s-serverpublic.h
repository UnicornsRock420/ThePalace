/*
 * s-serverpublic.h
 *
 * Declarations of types and constants used in the Palace server that are
 * publically visible (e.g., to plugins).
 *
 * Copyright 1999 Electric Communities. All rights reserved worldwide.
 */

#ifndef __SERVERPUBLIC__
#define __SERVERPUBLIC__

#include <ppsdk/local.h>

#define K       1024
#define M       (K*K)

#ifdef _WINNT

typedef enum { TT_NORMAL, TT_FILE, TT_ASSET, TT_AUTH } TRANSTYPE;

typedef struct tagCLIENT_IO_TRANSACTION
{
    TRANSTYPE   ttPacket;
    sint32      lTransID;
    Boolean     bWrite;
    OVERLAPPED  olTrans;
    LPBYTE      lpData;
    sint32      nDataLen;
    uint32      ownerID;  /* backward link to user record */
    sint32      refCount; /* for tracking lifespan of CLIENT_IO_TRANSACTION */
    IPAddress   userIP;
    SOCKET      socket;
} CLIENT_IO_TRANSACTION;

typedef CLIENT_IO_TRANSACTION* PCLIENT_IO_TRANSACTION;

#endif

#include <ppsdk/mansion.h>
#include <ppsdk/m-protocol.h>

/* Various static resource limits */
#define MaxHotspots         128
#define MaxSpotEvents        32
#define MaxSpotStates        32
#define MaxDrawCmds         128
#define MaxLProps           128
#define MaxFProps            64
#define MaxPanes              4

/* Per-client server flags */
#define SF_Suspended     0x00000001  /* obsolete, do not use */
#define SF_UsesSpotData  0x00000002  /* obsolete, do not use */
#define SF_HTTPSupport   0x00000004  /* Supports HTTP servers */
#define SF_DoubleByte    0x00000008  /* Client is double byte localized */
#define SF_PacketSigs    0x00000010  /* Client is using packet signatures */

/* Client flags from hub to frontend */
#define FE_OldClient 0x01

/* User action codes */
#define UA_HideFrom     0x01
#define UA_Mute         0x02
#define UA_Follow       0x04
#define UA_Kick         0x08

typedef struct UserActionRec {
    struct UserActionRec    *nextRec;
    UserID                   target;
    uint32                   actionFlags;
} UserActionRec, *UserActionPtr;

typedef struct
{
    IPAddress ipAddress;
    uint16    portNumber;
} UDPAddressRec;

/**
 * Struct representing a user on the server. This is a superset of the UserRec
 * struct which is shared between the client and the server.
 */
typedef struct ServerUserRec
{
    struct ServerUserRec *nextUser;
    int             connectionType;

    union {
        IPAddress   ipAddress;
#if defined(_WINDOWS) && !defined(_WINNT)
        SOCKET      socket;
#endif
#if TARGET_OS_MAC
        TargetID    appleTalkAddress;
#endif
        UDPAddressRec   udpAddress;
    } netAddress;

    uint32          crc;                /* Serial number */
    uint32          counter;
    time_t          lastActive;         /* Seconds */
    time_t          signonTime;
    int             oldSerialFlag;
    int             nbrPings;
    int             nbrFloodEvents;
    int             whyKilled;
    int             deathPenalty;
    uint16          flags;
    uint32          serverFlags;        /* Flags used internally only */
    uint16          frontendflags;      /* Flags to FE see FE_ */
    UserActionRec  *actionList;
    char            navPassword[32];    /* Used for password protected rooms */

#if TARGET_OS_MAC
    /* TCP Stuff */
    uint32          tcpStream;
    uint32          tcpRemoteHost;
    uint16          tcpRemotePort;
    TCPiopb        *tcpReceiveBlock;
    TCPiopb        *tcpSendBlock;
    Boolean         tcpReceiveFlag;
    Boolean         tcpSendFlag;
    char           *tcpReceiveBuffer;
    char           *tcpSendBuffer;
    char           *tcpSendPtr;
    sint32          tcpReceiveIdx;
    sint32          tcpSendLength;
#else

#ifdef _WINDOWS
    SOCKET          socket;
#ifdef _WINNT
    IPAddress   userIP;
#else
    int             socketIdx; 
#endif
#endif

#endif

#ifdef unix
    Boolean         tcpReceiveFlag;
    Boolean         tcpSendFlag;
    char           *tcpReceiveBuffer;
    char           *tcpSendBuffer;
    char           *tcpSendPtr;
    sint32          tcpReceiveIdx;
#if BISERVER
    void           *frontEnd;
    IPAddress       feIPAddr;
    uint16          feIPPort;
#else
    int             sockfd;
#endif
#endif

#ifndef _WINDOWS
    /* Group stuff - can be shared by both platforms... */
    int             groupFlag;
    char           *groupBuffer;
    sint32          groupLen;
    uint32          groupAlloc;

    /* Save verbal IP here for shrtcut (c-string) */
    char            verbalIP[256];
#endif  /* _WINDOWS */
    UserID          lastESPsender;
    struct ServerRoomRec *lastPasswordRoom;
    struct ServerRoomRec *lastOwnedRoom;
    int             nbrFailedPasswordAttempts;
    uint32          puidCtr;
    uint32          puidCRC;
    uint32          demoElapsed;
    uint32          totalElapsed;
    char            originationCode[7]; /* 6 data + 1 Null termination */
    char            machine[33];        /* For -o list option */
    Str31           wizPassword;
    RoomID          desiredRoom;
    Str31           username;           /* Username for closed servers */
    Str63           password;           /* Password for closed servers */
    Str255          groups;             /* Groups this user belongs to */
    uint32          infoFlags;          /* Extended info */
    int             authAttempts;       /* # of auth attempts for this user */
    char            whyMsg[256];        /* Verbose kill message */
    Boolean         loggedOn;           /* True if they count as a 'user' */
    struct ServerRoomRec *room;
    char           *pluginUserInfo;
    UserRec         user;
    char           *lastRoomMediaURL;   /* Last HTTP URL sent to client */
} ServerUserRec, *ServerUserPtr;

/* User ranks */
#define RANK_GUEST      0
#define RANK_MEMBER     1
#define RANK_WIZARD     2
#define RANK_GOD        3

#define BR_SiteBan1		0x01
#define BR_SiteBan2		0x02
#define BR_AllInclusive		0x04	/* Members Too */
#define BR_Tracking		0x08	/* used for tracking ips */

/* 1/14/97 JAB */
#define BR_PuidKey		0x10	/* used to track guests */

typedef struct IPBanRec {
    struct IPBanRec *nextRec;
    int         banFlags;
    int         ipAddress;
    uint32      regKey;
    int         timeLastPenalized;
    int         penaltyTime;
    int         whyBanned;
    char        verbalIP[128];
    char        userName[32];
    char        whoKilled[32];  /* 4/15/96 */
    char        comment[256];   /* 4/15/96 */
} IPBanRec, *IPBanRecPtr;

/* Reserved pseudo-propID for Type 1 loose props */
#define TYPE1_AVATAR_PROPID  256

/* Member room commands */
enum { MR_Title,  MR_Picture, MR_Owner,   MR_Kick,   MR_Unkick,   MR_Password,
       MR_Close,  MR_Open,    MR_Scripts, MR_Guests, MR_Painting, MR_Hide,
       MR_Unhide, MR_Delete,  MR_NbrCommands };

/** Server room flags */
#define SRF_NonPersistent       0x0001
#define SRF_Deleted             0x0002

/**
 * Struct representing a room on the server. This is a superset of the RoomRec
 * struct which is shared between the client and the server.
 */
typedef struct ServerRoomRec {
#if defined(_WINDOWS) && defined(_MT)
    void   *pSynchro;           /* Synchronization object for threading */
#endif
    struct ServerRoomRec *nextRoom; /* gRoomList chain link */
    UserID *occupants;          /* Users currently in the room */
    UserID  lastPainter;        /* For tracking who is painting */
    int     maxOccupancy;       /* If 0 defer to global roomOccupancy */
    int     maxGuests;          /* If 0, don't use */

    ClientID memberOwner;       /* Member owned rooms (0 for public rooms) */
    char    roomPassword[32];   /* Room password */
    
    char    roomPaneURL[MaxPanes][256]; /* Advertising room URL */

    uint32  varBufAlloc;        /* Extra space in RoomRec */
    char   *varBuf;             /* Separately allocated room.varBuf */
    char   *pluginRoomInfo;     /* Space allocated on behalf of plugins */
    RoomRec room;               /* The RoomRec shared with client */
    char   *roomMediaURL;       /* HTTP URL for this room, NULL ==> default */
    uint32  flags;
    RoomID  forwardRoom;
} ServerRoomRec, *ServerRoomPtr;

#define SO_SaveSessionKeys  0x00000001UL
#define SO_PasswordSecurity 0x00000002UL
#define SO_ChatLog          0x00000004UL
#define SO_NoWhisper        0x00000008UL
#define SO_Authenticate     0x00000020UL
#define SO_PoundProtect     0x00000040UL
#define SO_AuthTrackLogoff  0x00000100UL /* Auth demon wants logoff events */
#define SO_JavaSecure       0x00000200UL /* Allow Java users on closed servr */
#define SO_MotelSupport     0x00000400UL /* Server supports motel functions */
#define SO_ViewWithTPV      0x00000800UL /* View this palace button uses TPV (Mac Only) */

/**
 * Information on where a message should be sent.
 */
typedef struct MsgFanoutStruct MsgFanout; /* opaque outside of s-msgfan.c */

/* XXX copied from u-user.h - it really should be in a *shared* header file */
typedef struct {
    sint16   width;
    sint16   height;
    sint16   hOffset;
    sint16   vOffset;
    sint16   scriptOffset;
    sint16   flags;
} PropHeader, *PropHeaderPtr;

/* Result codes from server command functions */
typedef enum {
    CR_OK_NO_CHANGE,     /* all's well, but nothing changed */
    CR_OK_PREFS_CHANGE,  /* all's well, you need to write the prefs file */
    CR_ERR_USAGE,        /* syntax errors and the like */
    CR_ERR_OTHER         /* something other than syntax was wrong */
} CommandResult;

#endif /* __SERVERPUBLIC__ */
